//import * as amityglobalbusinessschool from '../../assets/universityData/amity-global-business-school'
//import * as amityinstituteofinformationtechnologymumbai from '../../assets/universityData/amity-institute-of-information-technology'
import * as avicennatajikstatemedicaluniversity from '../../assets/universityData/avicenna-tajik-state-medical-university'
import * as bridgetowninternationaluniversity from '../../assets/universityData/bridgetown-international-university'
import * as alteuniversitygeorgia from '../../assets/universityData/alte-university-georgia'
import * as caspianinternationalschoolofmedicine from '../../assets/universityData/caspian-international-school-of-medicine'
import * as siberianstatemedicaluniversity from '../../assets/universityData/siberian-state-medical-university'
import * as saintpetersburgstateinstituteoftechnology from '../../assets/universityData/saint-petersburg-state-institute-of-technology'
import * as nationalmetallurgicalacademyofukraine from '../../assets/universityData/national-metallurgical-academy-of-ukraine'
import * as permstatemedicaluniversity from '../../assets/universityData/perm-state-medical-university'
import * as southkazakhstanmedicalacademy from '../../assets/universityData/south-kazakhstan-medical-academy'
import * as grigolrobakidzeuniversity from '../../assets/universityData/grigol-robakidze-university'
import * as universityofregina from '../../assets/universityData/university-of-regina'
import * as kurskstatemedicaluniversity from '../../assets/universityData/kursk-state-medical-university'
import * as universityforthecreativearts from '../../assets/universityData/university-for-the-creative-arts'
import * as altaistatemedicaluniversity from '../../assets/universityData/altai-state-medical-university'
import * as bauinternationaluniversitybatumi from '../../assets/universityData/bau-international-university-batumi'
import * as universityofchittagong from '../../assets/universityData/university-of-chittagong'
import * as jalalabadstateuniversity from '../../assets/universityData/jalalabad-state-university'
import * as internationalhigherschoolofmedicine from '../../assets/universityData/international-higher-school-of-medicine'
import * as ivanovostatemedicalacademy from '../../assets/universityData/ivanovo-state-medical-academy'
import * as privolzhskyresearchmedicaluniversity from '../../assets/universityData/privolzhsky-research-medical-university'
import * as tulastateuniversity from '../../assets/universityData/tula-state-university'
import * as addinwomensmedicalcollege from '../../assets/universityData/ad-din-womens-medical-college'
import * as anwerkhanmodernmedicalcollege from '../../assets/universityData/anwer-khan-modern-medical-college'
import * as dhakacentralinternationalmedicalcollege from '../../assets/universityData/dhaka-central-international-medical-college'
import * as dhakacommunitymedicalcollege from '../../assets/universityData/dhaka-community-medical-college'
import * as drsirajulislammedicalcollege from '../../assets/universityData/dr-sirajul-islam-medical-college'
import * as enammedicalcollegeandhospital from '../../assets/universityData/enam-medical-college-and-hospital'
import * as gonoshasthayasamajvittikmedicalcollege from '../../assets/universityData/gonoshasthaya-samaj-vittik-medical-college'
import * as berlinschoolofbusinessandinnovation from '../../assets/universityData/berlin-school-of-business-and-innovation'
import * as avicennainternationalmedicaluniversity from '../../assets/universityData/avicenna-international-medical-university'
import * as bpkoiralainstituteofhealthsciences from '../../assets/universityData/b-p-koirala-institute-of-health-sciences'
import * as biratmedicalcollege from '../../assets/universityData/birat-medical-college'
import * as devdahamedicalcollegeandresearchinstitute from '../../assets/universityData/devdaha-medical-college-and-research-institute'
import * as ivanofrankivsknationaluniversityofoilandgas from '../../assets/universityData/ivano-frankivsk-national-university-of-oil-and-gas'
import * as jahurulislammedicalcollege from '../../assets/universityData/jahurul-islam-medical-college'
import * as khwajayunusalimedicalcollege from '../../assets/universityData/khwaja-yunus-ali-medical-college'
import * as kumudiniwomensmedicalcollege from '../../assets/universityData/kumudini-womens-medical-college'
import * as mainamotimedicalcollege from '../../assets/universityData/mainamoti-medical-college'
import * as monnomedicalcollegeandhospital from '../../assets/universityData/monno-medical-college-and-hospital'
import * as parkviewmedicalcollege from '../../assets/universityData/parkview-medical-college'
import * as presidentabdulhamidmedicalcollege from '../../assets/universityData/president-abdul-hamid-medical-college'
import * as primemedicalcollege from '../../assets/universityData/prime-medical-college'
import * as rangpurcommunitymedicalcollege from '../../assets/universityData/rangpur-community-medical-college'
import * as shahabuddinmedicalcollege from '../../assets/universityData/shahabuddin-medical-college'
import * as universityofexeter from '../../assets/universityData/university-of-exeter'
import * as universityofstrathclyde from '../../assets/universityData/university-of-strathclyde'
import * as velloreinstituteoftechnologyvitvellore from '../../assets/universityData/vellore-institute-of-technology-vit-vellore'
import * as nationalaerospaceuniversity from '../../assets/universityData/national-aerospace-university'
import * as uzhhorodnationalmedicaluniversity from '../../assets/universityData/uzhhorod-national-medical-university'
import * as bogomoletsnationalmedicaluniversity from '../../assets/universityData/bogomolets-national-medical-university'
import * as universitycollegelondon from '../../assets/universityData/university-college-london'
import * as ternopilnationaltechnicaluniversity from '../../assets/universityData/ternopil-national-technical-university'
import * as keeleuniversity from '../../assets/universityData/keele-university'
import * as iuinternationaluniversityofappliedsciences from '../../assets/universityData/iu-international-university-of-applied-sciences'
import * as aghuniversityofscienceandtechnology from '../../assets/universityData/agh-university-of-science-and-technology'
import * as kyivschoolofeconomics from '../../assets/universityData/kyiv-school-of-economics'
import * as wroclawmedicaluniversity from '../../assets/universityData/wroclaw-medical-university'
import * as mitworldpeaceuniversity from '../../assets/universityData/mit-world-peace-university'
import * as gismabusinessschool from '../../assets/universityData/gisma-business-school'
import * as wenzhoumedicaluniversity from '../../assets/universityData/wenzhou-medical-university'
import * as glasgowcaledonianuniversity from '../../assets/universityData/glasgow-caledonian-university'
import * as tbilisimedicaluniversityhippocrates from '../../assets/universityData/tbilisi-medical-university-hippocrates'
import * as qiqiharmedicaluniversity from '../../assets/universityData/qiqihar-medical-university'
import * as medicaluniversityofverna from '../../assets/universityData/medical-university-of-verna'
import * as universityofbologna from '../../assets/universityData/university-of-bologna'
import * as immanuelkantbalticfederaluniversity from '../../assets/universityData/immanuel-kant-baltic-federal-university'
import * as peoplesfriendshipuniversityofrussia from '../../assets/universityData/peoples-friendship-university-of-russia'
import * as belarusianstatemedicaluniversity from '../../assets/universityData/belarusian-state-medical-university'
import * as zaporozhyestatemedicaluniversity from '../../assets/universityData/zaporozhye-state-medical-university'
import * as batumishotarustavelistateuniversity from '../../assets/universityData/batumi-shota-rustaveli-state-university'
import * as lancasteruniversity from '../../assets/universityData/lancaster-university'
import * as balticinternationalacademy from '../../assets/universityData/baltic-international-academy'
import * as canterburychristchurchuniversity from '../../assets/universityData/canterbury-christ-church-university'
import * as corvinusuniversityofbudapest from '../../assets/universityData/corvinus-university-of-budapest'
import * as daugavpilsuniversity from '../../assets/universityData/daugavpils-university'
import * as dnipropetrovskstatemedicalacademy from '../../assets/universityData/dnipropetrovsk-state-medical-academy'
import * as donetsknationalmedicaluniversity from '../../assets/universityData/donetsk-national-medical-university'
import * as frankfurtschooloffinanceandmanagement from '../../assets/universityData/frankfurt-school-of-finance-and-management'
import * as kyivpolytechnicinstitute from '../../assets/universityData/kyiv-polytechnic-institute'
import * as kyrgyznationaluniversity from '../../assets/universityData/kyrgyz-national-university'
import * as northernstatemedicaluniversity from '../../assets/universityData/northern-state-medical-university'
import * as ogarevmordoviastateuniversity from '../../assets/universityData/ogarev-mordovia-state-university'
import * as petergreatstpetersburgpolytechnicuniversity from '../../assets/universityData/peter-great-st-petersburg-polytechnic-university'
import * as plovdivmedicaluniversity from '../../assets/universityData/plovdiv-medical-university'
import * as pskovstatepolytechnicinstitute from '../../assets/universityData/pskov-state-polytechnic-institute'
import * as pskovstateuniversity from '../../assets/universityData/pskov-state-university'
import * as smolenskstatemedicaluniversity from '../../assets/universityData/smolensk-state-medical-university'
import * as tallinnuniversityoftechnology from '../../assets/universityData/tallinn-university-of-technology'
import * as tbilisipublicuniversitymetekhi from '../../assets/universityData/tbilisi-public-university-metekhi'
import * as tribhuvanuniversity from '../../assets/universityData/tribhuvan-university'
import * as universitycanadawest from '../../assets/universityData/university-canada-west'
import * as universityofalberta from '../../assets/universityData/university-of-alberta'
import * as universityofwolverhampton from '../../assets/universityData/university-of-wolverhampton'
import * as xinjianguniversity from '../../assets/universityData/xinjiang-university'
import * as yangzhouuniversity from '../../assets/universityData/yangzhou-university'
import * as aberystwythuniversity from '../../assets/universityData/aberystwyth-university'
import * as belgorodstateuniversity from '../../assets/universityData/belgorod-state-university'
import * as bukovinianstatemedicaluniversity from '../../assets/universityData/bukovinian-state-medical-university'
import * as capitalmedicaluniversity from '../../assets/universityData/capital-medical-university'
import * as cherkasystatetechnologicaluniversity from '../../assets/universityData/cherkasy-state-technological-university'
import * as crimeanfederaluniversity from '../../assets/universityData/crimean-federal-university'
import * as danylohalytskylvivstatemedicaluniversity from '../../assets/universityData/danylo-halytsky-lviv-state-medical-university'
import * as durhamuniversity from '../../assets/universityData/durham-university'
import * as lvivpolytechnicnationaluniversity from '../../assets/universityData/lviv-polytechnic-national-university'
import * as gdanskuniversityoftechnology from '../../assets/universityData/gdansk-university-of-technology'
import * as georgiannationaluniversityseu from '../../assets/universityData/georgian-national-university-seu'
import * as jilinuniversity from '../../assets/universityData/jilin-university'
import * as jinanuniversity from '../../assets/universityData/jinan-university'
import * as kabardinobalkarianstateuniversity from '../../assets/universityData/kabardino-balkarian-state-university'
import * as kyivmedicaluniversityofuafmkiev from '../../assets/universityData/kyiv-medical-university-of-uafm-kiev'
import * as londonmetropolitanuniversity from '../../assets/universityData/london-metropolitan-university'
import * as medicaluniversityoflublin from '../../assets/universityData/medical-university-of-lublin'
import * as medicaluniversityofsilesia from '../../assets/universityData/medical-university-of-silesia'
import * as medicaluniversityofwarsaw from '../../assets/universityData/medical-university-of-warsaw'
import * as moscowuniversitytouro from '../../assets/universityData/moscow-university-touro'
import * as nicolauscopernicusuniversity from '../../assets/universityData/nicolaus-copernicus-university'
import * as nizhnynovgorodstatetechnicaluniversity from '../../assets/universityData/nizhny-novgorod-state-technical-university'
import * as northkazakhstanstateuniversity from '../../assets/universityData/north-kazakhstan-state-university'
import * as orelstateuniversity from '../../assets/universityData/orel-state-university'
import * as orenburgstatemedicaluniversity from '../../assets/universityData/orenburg-state-medical-university'
import * as poznanuniversityofmedicalscience from '../../assets/universityData/poznan-university-of-medical-science'
import * as reutlingenuniversity from '../../assets/universityData/reutlingen-university'
import * as risebauniversityofbusinessartsandtechnology from '../../assets/universityData/riseba-university-of-business-arts-and-technology'
import * as ryersonuniversity from '../../assets/universityData/ryerson-university'
import * as simonfraseruniversity from '../../assets/universityData/simon-fraser-university'
import * as stterezamedicaluniversity from '../../assets/universityData/st-tereza-medical-university'
import * as universityofbradford from '../../assets/universityData/university-of-bradford'
import * as universityofbristol from '../../assets/universityData/university-of-bristol'
import * as universityoflatvia from '../../assets/universityData/university-of-latvia'
import * as universityofottawa from '../../assets/universityData/university-of-ottawa'
import * as universityofperpetualhelpsystemdalta from '../../assets/universityData/university-of-perpetual-help-system-dalta'
import * as universityofsaskatchewan from '../../assets/universityData/university-of-saskatchewan'
import * as universityofstandrews from '../../assets/universityData/university-of-st-andrews'
import * as universityofwarmiaandmazury from '../../assets/universityData/university-of-warmia-and-mazury'
import * as vitebskstatemedicaluniversity from '../../assets/universityData/vitebsk-state-medical-university'
import * as vnkarazinkharkivnationaluniversity from '../../assets/universityData/v-n-karazin-kharkiv-national-university'
import * as volgogradstatemedicaluniversity from '../../assets/universityData/volgograd-state-medical-university'
import * as warsawuniversityoftechnology from '../../assets/universityData/warsaw-university-of-technology'
import * as yaroslavlstatemedicaluniversity from '../../assets/universityData/yaroslavl-state-medical-university'
import * as bashkirstatemedicaluniversity from '../../assets/universityData/bashkir-state-medical-university'
import * as cracowuniversityoftechnology from '../../assets/universityData/cracow-university-of-technology'
import * as fareasternfederaluniversity from '../../assets/universityData/far-eastern-federal-university'
import * as flameuniversitypune from '../../assets/universityData/flame-university-pune'
import * as gdanskmedicaluniversity from '../../assets/universityData/gdansk-medical-university'
import * as gomelstatemedicaluniversity from '../../assets/universityData/gomel-state-medical-university'
import * as guangximedicaluniversity from '../../assets/universityData/guangxi-medical-university'
import * as humboldtuniversityofberlin from '../../assets/universityData/humboldt-university-of-berlin'
import * as kalmykstateuniversity from '../../assets/universityData/kalmyk-state-university'
import * as kharkivnationaluniversityofarts from '../../assets/universityData/kharkiv-national-university-of-arts'
import * as kubanstatemedicaluniversity from '../../assets/universityData/kuban-state-medical-university'
import * as lazarskiuniversity from '../../assets/universityData/lazarski-university'
import * as medicaluniversityofpleven from '../../assets/universityData/medical-university-of-pleven'
import * as omskstatemedicaluniversity from '../../assets/universityData/omsk-state-medical-university'
import * as oshstateuniversity from '../../assets/universityData/osh-state-university'
import * as patanacademyofhealthsciences from '../../assets/universityData/patan-academy-of-health-sciences'
import * as russiannationalresearchmedicaluniversity from '../../assets/universityData/russian-national-research-medical-university'
import * as silesianuniversityoftechnology from '../../assets/universityData/silesian-university-of-technology'
import * as sofiamedicaluniversity from '../../assets/universityData/sofia-medical-university'
import * as southernmedicaluniversity from '../../assets/universityData/southern-medical-university'
import * as tyumenstatemedicaluniversity from '../../assets/universityData/tyumen-state-medical-university'
import * as universityofdebrecen from '../../assets/universityData/university-of-debrecen'
import * as universityofdhaka from '../../assets/universityData/university-of-dhaka'
import * as universityofstuttgart from '../../assets/universityData/university-of-stuttgart'
import * as universityofwarwick from '../../assets/universityData/university-of-warwick'
import * as uralstatemedicaluniversity from '../../assets/universityData/ural-state-medical-university'
import * as westkazakhstanmaratospanovstatemedicaluniversity from '../../assets/universityData/west-kazakhstan-marat-ospanov-state-medical-university'
import * as xianjiaotonguniversity from '../../assets/universityData/xian-jiaotong-university'
import * as yerevanhaybusakuniversity from '../../assets/universityData/yerevan-haybusak-university'
import * as budapestmetropolitanuniversity from '../../assets/universityData/budapest-metropolitan-university'
import * as bukharastatemedicalinstitute from '../../assets/universityData/bukhara-state-medical-institute'
import * as carletonuniversity from '../../assets/universityData/carleton-university'
import * as caucasusinternationaluniversity from "../../assets/universityData/caucasus-international-university"
import * as ivanejavakhishvilitbilisistateuniversity from '../../assets/universityData/ivane-javakhishvili-tbilisi-state-university'
import * as johannesgutenberguniversitymainz from '../../assets/universityData/johannes-gutenberg-university-mainz'
import * as klaipedauniversity from '../../assets/universityData/klaipeda-university'
import * as lvivnationalacademyofarts from '../../assets/universityData/lviv-national-academy-of-arts'
import * as odessanationalmedicaluniversity from '../../assets/universityData/odessa-national-medical-university'
import * as ryazanstatemedicaluniversity from '../../assets/universityData/ryazan-state-medical-university'
import * as tbilisiopenteachinguniversity from '../../assets/universityData/tbilisi-open-teaching-university'
import * as universityofcologne from '../../assets/universityData/university-of-cologne'
import * as universityofwindsor from '../../assets/universityData/university-of-windsor'
import * as yerevanstatemedicaluniversity from '../../assets/universityData/yerevan-state-medical-university'
import * as zaporizhzhiastateengineeringacademy from '../../assets/universityData/zaporizhzhia-state-engineering-academy'
import * as zhejiangmedicaluniversity from '../../assets/universityData/zhejiang-medical-university'
import * as astanamedicaluniversity from '../../assets/universityData/astana-medical-university'
import * as astrakhanstatemedicaluniversity from '../../assets/universityData/astrakhan-state-medical-university'
import * as bangladeshuniversityofprofessionals from '../../assets/universityData/bangladesh-university-of-professionals'
import * as davidtvildianimedicaluniversity from '../../assets/universityData/david-tvildiani-medical-university'
import * as fudanuniversity from '../../assets/universityData/fudan-university'
import * as irkutskstatemedicaluniversity from '../../assets/universityData/irkutsk-state-medical-university'
import * as jagiellonianuniversitymedicalcollege from '../../assets/universityData/jagiellonian-university-medical-college'
import * as kazakhrussianmedicaluniversity from '../../assets/universityData/kazakh-russian-medical-university'
import * as kremenchukstatetechnicaluniversity from '../../assets/universityData/kremenchuk-state-technical-university'
import * as luganskstatemedicaluniversity from '../../assets/universityData/lugansk-state-medical-university'
import * as moscowstateuniversityofcivilengineering from '../../assets/universityData/moscow-state-university-of-civil-engineering'
import * as nationaluniversityofscienceandtechnologymisis from '../../assets/universityData/national-university-of-science-and-technology-misis'
import * as northcaucasusfederaluniversity from '../../assets/universityData/north-caucasus-federal-university'
import * as pavlovfirstsaintpetersburgstatemedicaluniversity from '../../assets/universityData/pavlov-first-saint-petersburg-state-medical-university'
import * as sumystateuniversity from '../../assets/universityData/sumy-state-university'
import * as technischehochschuleingolstadt from '../../assets/universityData/technische-hochschule-ingolstadt'
import * as tverstatemedicaluniversity from '../../assets/universityData/tver-state-medical-university'
import * as ufastateaviationtechnicaluniversity from '../../assets/universityData/ufa-state-aviation-technical-university'
import * as ulyanovskstateuniversity from '../../assets/universityData/ulyanovsk-state-university'
import * as universityofeconomicsinkatowice from '../../assets/universityData/university-of-economics-in-katowice'
import * as universityofgloucestershire from '../../assets/universityData/university-of-gloucestershire'
import * as vinnitsanationalmedicaluniversity from '../../assets/universityData/vinnitsa-national-medical-university'
import * as warsawschoolofeconomicssgh from '../../assets/universityData/warsaw-school-of-economics-sgh'
import * as yorkstjohnuniversity from '../../assets/universityData/york-st-john-university'
import * as alfarabikazakhnationaluniversity from '../../assets/universityData/al-farabi-kazakh-national-university'
import * as amaschoolofmedicine from '../../assets/universityData/ama-school-of-medicine'
import * as andijanstatemedicalinstitute from '../../assets/universityData/andijan-state-medical-institute'
import * as angelesuniversityfoundation from '../../assets/universityData/angeles-university-foundation'
import * as bathspauniversity from '../../assets/universityData/bath-spa-university'
import * as carlbenzschoolofengineering from '../../assets/universityData/carl-benz-school-of-engineering'
import * as centralphilippineuniversity from '../../assets/universityData/central-philippine-university'
import * as chongqingmedicaluniversity from '../../assets/universityData/chongqing-medical-university'
import * as christuniversitybangalore from '../../assets/universityData/christ-university-bangalore'
import * as karlsruheinstituteoftechnology from '../../assets/universityData/karlsruhe-institute-of-technology'
import * as cityuniversityoflondon from '../../assets/universityData/city-university-of-london'
import * as dalianmedicaluniversity from '../../assets/universityData/dalian-medical-university'
import * as davidagmashenebeliuniversityofgeorgia from '../../assets/universityData/david-agmashenebeli-university-of-georgia'
import * as donbassstateengineeringacademy from '../../assets/universityData/donbass-state-engineering-academy'
import * as esslingenuniversityofappliedsciences from '../../assets/universityData/esslingen-university-of-applied-sciences'
import * as firstmoscowstatemedicaluniversity from '../../assets/universityData/first-moscow-state-medical-university'
import * as grodnostatemedicaluniversity from '../../assets/universityData/grodno-state-medical-university'
import * as internationalschoolofmanagementdortmund from '../../assets/universityData/international-school-of-management-dortmund'
import * as gurugobindsinghindraprasthauniversitydelhi from '../../assets/universityData/guru-gobind-singh-indraprastha-university-delhi'
import * as irkutsknationalresearchtechnicaluniversity from '../../assets/universityData/irkutsk-national-research-technical-university'
import * as jamiamilliaislamiadelhi from '../../assets/universityData/jamia-millia-islamia-delhi'
import * as karagandastatemedicaluniversity from '../../assets/universityData/karaganda-state-medical-university'
import * as kazanfederaluniversity from '../../assets/universityData/kazan-federal-university'
import * as kharkivnationalmedicaluniversity from '../../assets/universityData/kharkiv-national-medical-university'
import * as kharkivstateacademyofculture from '../../assets/universityData/kharkiv-state-academy-of-culture'
import * as khersonnationaltechnicaluniversity from '../../assets/universityData/kherson-national-technical-university'
import * as kingscollegelondon from '../../assets/universityData/kings-college-london'
import * as kokshetaustateuniversity from '../../assets/universityData/kokshetau-state-university'
import * as kyivnationaluniversityofcultureandarts from '../../assets/universityData/kyiv-national-university-of-culture-and-arts'
import * as leedsbeckettuniversity from '../../assets/universityData/leeds-beckett-university'
import * as medicaluniversityoflodz from '../../assets/universityData/medical-university-of-lodz'
import * as mkhitargosharmenianrussianinternationaluniversity from '../../assets/universityData/mkhitar-gosh-armenian-russian-international-university'
import * as moscowinstituteofphysicsandtechnology from '../../assets/universityData/moscow-institute-of-physics-and-technology'
import * as moscowpowerengineeringinstitute from '../../assets/universityData/moscow-power-engineering-institute'
import * as narseemonjeeinstituteofmanagementstudiesnmimsmumbai from '../../assets/universityData/narsee-monjee-institute-of-management-studies-nmims-mumbai'
import * as northossetianstatemedicalacademy from '../../assets/universityData/north-ossetian-state-medical-academy'
import * as novosibirsknationalresearchstateuniversity from '../../assets/universityData/novosibirsk-state-university'
import * as permstateagrotechnologicaluniversity from '../../assets/universityData/perm-state-agro-technological-university'
import * as petreshotadzetbilisimedicalacademy from '../../assets/universityData/petre-shotadze-tbilisi-medical-academy'
import * as petromohylablackseanationaluniversity from '../../assets/universityData/petro-mohyla-black-sea-national-university'
import * as poltavastatemedicalanddentaluniversity from '../../assets/universityData/poltava-state-medical-and-dental-university'
import * as queensuniversity from '../../assets/universityData/queens-university'
import * as samarastateaerospaceuniversity from '../../assets/universityData/samara-state-aerospace-university'
import * as samarastatemedicaluniversity from '../../assets/universityData/samara-state-medical-university'
import * as shandonguniversity from '../../assets/universityData/shandong-university'
import * as sichuanuniversity from '../../assets/universityData/sichuan-university'
import * as stpetersburgstatepediatricmedicaluniversity from '../../assets/universityData/st-petersburg-state-pediatric-medical-university'
import * as stpauluniversityphilippines from '../../assets/universityData/st-paul-university-philippines'
import * as symbiosisinternationaluniversitysiupune from '../../assets/universityData/symbiosis-international-university-siu-pune'
import * as tambovstateuniversity from '../../assets/universityData/tambov-state-university'
import * as universityofedinburgh from '../../assets/universityData/university-of-edinburgh'
import * as transportandtelecommunicationinstitute from '../../assets/universityData/transport-and-telecommunication-institute'
import * as universityofmanchester from '../../assets/universityData/university-of-manchester'
import * as universityofnorthernphilippines from '../../assets/universityData/university-of-northern-philippines'
import * as universityofpavia from '../../assets/universityData/university-of-pavia'
import * as universityofrajshahi from '../../assets/universityData/university-of-rajshahi'
import * as universityofsouthwales from '../../assets/universityData/university-of-south-wales'
import * as universityoftraditionalmedicine from '../../assets/universityData/university-of-traditional-medicine'
import * as vilniauskolegijauniversityofappliedsciences from '../../assets/universityData/vilniaus-kolegija-university-of-applied-sciences'
import * as warsawuniversityoftechnologybusinessschool from '../../assets/universityData/warsaw-university-of-technology-business-school'
import * as wuhanuniversity from '../../assets/universityData/wuhan-university'
import * as armenianmedicalinstitute from '../../assets/universityData/armenian-medical-institute'
import * as iliastateuniversity from '../../assets/universityData/ilia-state-university'
import * as collegiumdavinci from '../../assets/universityData/collegium-da-vinci'
import * as georgianamericanuniversity from '../../assets/universityData/georgian-american-university'
import * as kazakhnationalmedicaluniversity from '../../assets/universityData/kazakh-national-medical-university'
import * as kharkivinternationalmedicaluniversity from '../../assets/universityData/kharkiv-international-medical-university'
import * as ningxiauniversity from '../../assets/universityData/ningxia-university'
import * as royalcollegeofart from '../../assets/universityData/royal-college-of-art'
import * as tomskpolytechnicuniversity from '../../assets/universityData/tomsk-polytechnic-university'
import * as ukrainianstatechemicaltechnologyuniversity from '../../assets/universityData/ukrainian-state-chemical-technology-university'
import * as universityofsussex from '../../assets/universityData/university-of-sussex'
import * as baumanmoscowstatetechnicaluniversity from '../../assets/universityData/bauman-moscow-state-technical-university'
import * as chuvashstateuniversity from '../../assets/universityData/chuvash-state-university'
import * as itmouniversity from '../../assets/universityData/itmo-university'
import * as kazakhmedicaluniversityofcontinuingeducation from '../../assets/universityData/kazakh-medical-university-of-continuing-education'
import * as kharkivnationaluniversityofradioelectronics from '../../assets/universityData/kharkiv-national-university-of-radio-electronics'
import * as kingstonuniversitylondon from '../../assets/universityData/kingston-university-london'
import * as lodzuniversityoftechnology from '../../assets/universityData/lodz-university-of-technology'
import * as lomonosovmoscowstateuniversitybusinessschool from '../../assets/universityData/lomonosov-moscow-state-university-business-school'
import * as lomonosovmoscowstateuniversity from '../../assets/universityData/lomonosov-moscow-state-university'
import * as middlesexuniversitylondon from '../../assets/universityData/middlesex-university-london'
import * as newvisionuniversity from '../../assets/universityData/new-vision-university'
import * as shahjalaluniversityofscienceandtechnology from '../../assets/universityData/shahjalal-university-of-science-and-technology'
import * as shivajiuniversitykolhapur from '../../assets/universityData/shivaji-university-kolhapur'
import * as southwesternuniversityphinma from '../../assets/universityData/southwestern-university-phinma'
import * as universityofbedfordshire from '../../assets/universityData/university-of-bedfordshire'
import * as universityofcambridge from '../../assets/universityData/university-of-cambridge'
import * as universityofmannheim from '../../assets/universityData/university-of-mannheim'
import * as universityofmiskolc from '../../assets/universityData/university-of-miskolc'
import * as vistulauniversity from '../../assets/universityData/vistula-university'
import * as bppuniversity from '../../assets/universityData/bpp-university'
import * as cardiffmetropolitanuniversity from '../../assets/universityData/cardiff-metropolitan-university'
import * as cebuinstituteofmedicine from '../../assets/universityData/cebu-institute-of-medicine'
import * as estonianacademyofarts from '../../assets/universityData/estonian-academy-of-arts'
import * as geomedistateuniversity from '../../assets/universityData/geomedi-state-university'
import * as kemerovostatemedicaluniversity from '../../assets/universityData/kemerovo-state-medical-university'
import * as kyrgyzrussianslavicuniversity from '../../assets/universityData/kyrgyz-russian-slavic-university'
import * as moscowaviationinstitute from '../../assets/universityData/moscow-aviation-institute'
import * as semeystatemedicaluniversity from '../../assets/universityData/semey-state-medical-university'
import * as stavropolstatemedicaluniversity from '../../assets/universityData/stavropol-state-medical-university'
import * as szentistvanuniversity from '../../assets/universityData/szent-istvan-university'
import * as tarasshevchenkonationaluniversityofkyiv from '../../assets/universityData/taras-shevchenko-national-university-of-kyiv'
import * as tashkentmedicalacademy from '../../assets/universityData/tashkent-medical-academy'
import * as universityofgeorgiatbilisi from '../../assets/universityData/university-of-georgia-tbilisi'
import * as universityofpisa from '../../assets/universityData/university-of-pisa'
import * as bocconiuniversity from '../../assets/universityData/bocconi-university'
import * as bruneluniversitylondon from '../../assets/universityData/brunel-university-london'
import * as budapestuniversityoftechnologyandeconomics from '../../assets/universityData/budapest-university-of-technology-and-economics'
import * as camosuncollege from '../../assets/universityData/camosun-college'
import * as chechenstateuniversity from '../../assets/universityData/chechen-state-university'
import * as dagestanstatemedicaluniversity from '../../assets/universityData/dagestan-state-medical-university'
import * as dalhousieuniversity from '../../assets/universityData/dalhousie-university'
import * as eubusinessschoolmunich from '../../assets/universityData/eu-business-school-munich'
import * as fanshawecollege from '../../assets/universityData/fanshawe-college'
import * as lambtoncollege from '../../assets/universityData/lambton-college'
import * as lvivbusinessschoolofukrainiancatholicuniversity from '../../assets/universityData/lviv-business-school-of-ukrainian-catholic-university'
import * as maristateuniversity from '../../assets/universityData/mari-state-university'
import * as mcmasteruniversity from '../../assets/universityData/mcmaster-university'
import * as medicaluniversityofbialystok from '../../assets/universityData/medical-university-of-bialystok'
import * as moscowstateuniversityoffinechemicaltechnologies from '../../assets/universityData/moscow-state-university-of-fine-chemical-technologies'
import * as munichbusinessschool from '../../assets/universityData/munich-business-school'
import * as novosibirskstateuniversity from '../../assets/universityData/novosibirsk-state-university'
import * as novosibirskstatetechnicaluniversity from '../../assets/universityData/novosibirsk-state-technical-university'
import * as pacificstatemedicaluniversity from '../../assets/universityData/pacific-state-medical-university'
import * as penzastatemedicaluniversity from '../../assets/universityData/penza-state-medical-university'
import * as russianpresidentialacademyofnationaleconomyandpublicadministration from '../../assets/universityData/russian-presidential-academy-of-national-economy-and-public-administration'
import * as saratovstatemedicaluniversity from '../../assets/universityData/saratov-state-medical-university'
import * as sheridancollege from '../../assets/universityData/sheridan-college'
import * as tairunnessamemorialmedicalcollege from '../../assets/universityData/tairunnessa-memorial-medical-college'
import * as tallinnhealthcarecollege from '../../assets/universityData/tallinn-health-care-college'
import * as tbilisistatemedicaluniversity from '../../assets/universityData/tbilisi-state-medical-university'
import * as ternopilnationalmedicaluniversity from '../../assets/universityData/ternopil-national-medical-university'
import * as theuniversityoflaw from '../../assets/universityData/the-university-of-law'
import * as trakiauniversity from '../../assets/universityData/trakia-university'
import * as universityoflincoln from '../../assets/universityData/university-of-lincoln'
import * as universityofoxford from '../../assets/universityData/university-of-oxford'
import * as universityofsurrey from '../../assets/universityData/university-of-surrey'
import * as universityofulm from '../../assets/universityData/university-of-ulm'
import * as usbanglamedicalcollege from '../../assets/universityData/us-bangla-medical-college'
import * as voronezhstatemedicaluniversity from '../../assets/universityData/voronezh-state-medical-university'
import * as wroclawuniversityoftechnology from '../../assets/universityData/wroclaw-university-of-technology'
import * as amecbicolchristiancollegeofmedicine from '../../assets/universityData/amec-bicol-christian-college-of-medicine'
import * as easteuropeanuniversity from '../../assets/universityData/east-european-university'
import * as romebusinessschool from '../../assets/universityData/rome-business-school'
import * as universityofpadua from '../../assets/universityData/university-of-padua'
import * as universityofsalford from '../../assets/universityData/university-of-salford'
import * as asianinstitutemanagementphilippines from '../../assets/universityData/asian-institute-management-philippines'
import * as asianmedicalinstitute from '../../assets/universityData/asian-medical-institute'
import * as belfastmetropolitancollege from '../../assets/universityData/belfast-metropolitan-college'
import * as brokenshirecollegeschoolofmedicine from '../../assets/universityData/brokenshire-college-school-of-medicine'
import * as davaomedicalschoolfoundation from '../../assets/universityData/davao-medical-school-foundation'
import * as emilioaguinaldocollegemanila from '../../assets/universityData/emilio-aguinaldo-college-manila'
import * as henleybusinessschool from '../../assets/universityData/henley-business-school'
import * as kathmandumedicalcollege from '../../assets/universityData/kathmandu-medical-college'
import * as kharkivstateacademyofdesignandarts from '../../assets/universityData/kharkiv-state-academy-of-design-and-arts'
import * as liceocollegeofmedicine from '../../assets/universityData/liceo-college-of-medicine'
import * as liverpoolhopeuniversity from '../../assets/universityData/liverpool-hope-university'
import * as londonschoolofeconomicsandpoliticalsciencelondon from '../../assets/universityData/london-school-of-economics-and-political-science-london'
import * as manipalcollegeofmedicalsciences from '../../assets/universityData/manipal-college-of-medical-sciences'
import * as moscowschoolofmanagementskolkovo from '../../assets/universityData/moscow-school-of-management-skolkovo'
import * as newcollegedurham from '../../assets/universityData/new-college-durham'
import * as ramonvdelrosariocollegeofbusiness from '../../assets/universityData/ramon-v-del-rosario-college-of-business'
import * as uvgullascollegeofmedicine from '../../assets/universityData/uv-gullas-college-of-medicine'
import * as washingtonsycipgraduateschoolofbusiness from '../../assets/universityData/washington-sycip-graduate-school-of-business'
import * as europeanuniversitygeorgia from '../../assets/universityData/european-university-georgia'
import * as jiangsuuniversity from '../../assets/universityData/jiangsu-university'
import * as uibinternationalmedicalschool from '../../assets/universityData/uib-international-medical-school'
import * as bharatividyapeethdeemeduniversitypune from '../../assets/universityData/bharati-vidyapeeth-deemed-university-pune'
import * as rostovstatemedicaluniversity from '../../assets/universityData/rostov-state-medical-university'
import * as izhevskstatemedicalacademy from '../../assets/universityData/izhevsk-state-medical-academy'
import * as ivanofrankivsknationalmedicaluniversity from '../../assets/universityData/ivano-frankivsk-national-medical-university'
import * as kyrgyzstatemedicalacademy from '../../assets/universityData/kyrgyz-state-medical-academy'
import * as lyceumnorthwesternuniversity from '../../assets/universityData/lyceum-northwestern-university'
import * as manilacentraluniversity from '../../assets/universityData/manila-central-university'
import * as nanjingmedicaluniversity from '../../assets/universityData/nanjing-medical-university'
import * as ourladyoffatimauniversity from '../../assets/universityData/our-lady-of-fatima-university'
import * as samarkandstatemedicalinstitute from '../../assets/universityData/samarkand-state-medical-institute'
import * as southuralstateuniversity from '../../assets/universityData/south-ural-state-university'
import * as tashkentstatedentalinstitute from '../../assets/universityData/tashkent-state-dental-institute'
import * as universityofsantotomas from '../../assets/universityData/university-of-santo-tomas'
import * as vinnytsianationaltechnicaluniversity from '../../assets/universityData/vinnytsia-national-technical-university'
import * as poznanuniversityoftechnology from '../../assets/universityData/poznan-university-of-technology'
import * as akakitseretelistateuniversity from '../../assets/universityData/akaki-tsereteli-state-university'
import * as kazanstatemedicaluniversity from '../../assets/universityData/kazan-state-medical-university'
import * as northeasternfederaluniversity from '../../assets/universityData/north-eastern-federal-university'
import * as jalalabadragibrabeyamedicalcollege from '../../assets/universityData/jalalabad-ragib-rabeya-medical-college'
import * as tianjinmedicaluniversity from '../../assets/universityData/tianjin-medical-university'
import * as nationalaviationuniversity from '../../assets/universityData/national-aviation-university'
import * as universityofbonn from '../../assets/universityData/university-of-bonn'
import * as rwthaachenuniversity from '../../assets/universityData/rwth-aachen-university'
import * as dhakanationalmedicalcollege from '../../assets/universityData/dhaka-national-medical-college'
import * as eotvosloranduniversity from '../../assets/universityData/eotvos-lorand-university'
import * as heidelberguniversity from '../../assets/universityData/heidelberg-university'
import * as heriotwattuniversity from '../../assets/universityData/heriot-watt-university'
import * as loughboroughuniversity from '../../assets/universityData/loughborough-university'
import * as poloniauniversity from '../../assets/universityData/polonia-university'
import * as universityofsuffolk from '../../assets/universityData/university-of-suffolk'
import * as universityoftrento from '../../assets/universityData/university-of-trento'
import * as ismuniversityofmanagementandeconomics from '../../assets/universityData/ism-university-of-management-and-economics'
import * as allindiainstituteofmedicalsciencesaiimsnewdelhi from '../../assets/universityData/all-india-institute-of-medical-sciences-aiims-new-delhi'
import * as nipissinguniversity from '../../assets/universityData/nipissing-university'
import * as northeasternuniversity from '../../assets/universityData/northeastern-university'
import * as paceuniversity from '../../assets/universityData/pace-university'
import * as purdueuniversity from '../../assets/universityData/purdue-university'
import * as queenslanduniversity from '../../assets/universityData/queensland-university'
import * as saintlouisuniversity from '../../assets/universityData/saint-louis-university'
import * as solentuniversity from '../../assets/universityData/solent-university'
import * as stanforduniversity from '../../assets/universityData/stanford-university'
import * as swinburneuniversity from '../../assets/universityData/swinburne-university'
import * as teessideuniversity from '../../assets/universityData/teesside-university'
import * as texasamuniversity from '../../assets/universityData/texas-a-m-university'
import * as universityofillinois from '../../assets/universityData/university-of-illinois'
import * as universityofnewcastle from '../../assets/universityData/university-of-newcastle'
import * as universityofqueensland from '../../assets/universityData/university-of-queensland'
import * as universityoftexasaustin from '../../assets/universityData/university-of-texas-austin'
import * as universityoftexasdallas from '../../assets/universityData/university-of-texas-dallas'
import * as universityofwesternaustralia from '../../assets/universityData/university-of-western-australia'
import * as torontometropolitanuniversity from '../../assets/universityData/toronto-metropolitan-university'
import * as torrensuniversity from '../../assets/universityData/torrens-university'
import * as trinitywesternuniversity from '../../assets/universityData/trinity-western-university'
import * as universityatbuffalo from '../../assets/universityData/university-at-buffalo'
import * as universityofcalgary from '../../assets/universityData/university-of-calgary'
import * as universityofcalifornia from '../../assets/universityData/university-of-california'
import * as universityofcanberra from '../../assets/universityData/university-of-canberra'
import * as universityofflorida from '../../assets/universityData/university-of-florida'
import * as universityofkent from '../../assets/universityData/university-of-kent'
import * as universityofnewhaven from '../../assets/universityData/university-of-newhaven'
import * as universityofnorthtexas from '../../assets/universityData/university-of-north-texas'
import * as universityofprinceedwardisland from '../../assets/universityData/university-of-prince-edward-island'
import * as universityofsouthflorida from '../../assets/universityData/university-of-south-florida'
import * as universityofsoutherncalifornia from '../../assets/universityData/university-of-southern-california'
import * as universityofsouthernqueensland from '../../assets/universityData/university-of-southern-queensland'
import * as universityoftechnology from '../../assets/universityData/university-of-technology'
import * as universityoftexasarlington from '../../assets/universityData/university-of-texas-arlington'
import * as universityofsunshinecoast from '../../assets/universityData/university-of-sunshine-coast'
import * as universityoftoronto from '../../assets/universityData/university-of-toronto'
import * as universityofwollongong from '../../assets/universityData/university-of-wollongong'
import * as vancouverislanduniversity from '../../assets/universityData/vancouver-island-university'
import * as victoriauniversitysydney from '../../assets/universityData/victoria-university-sydney'
import * as victoriauniversity from '../../assets/universityData/victoria-university'

import * as millenniaatlanticuniversity from '../../assets/universityData/millennia-atlantic-university'
import * as millersvilleuniversitypennsylvania from '../../assets/universityData/millersville-university-pennsylvania'
import * as milliganuniversitytennessee from '../../assets/universityData/milligan-university-tennessee'
import * as millikinuniversityillinois from '../../assets/universityData/millikin-university-illinois'
import * as minnesotastateuniversitymankato from '../../assets/universityData/minnesota-state-university-mankato'
import * as minnesotastateuniversitymoorhead from '../../assets/universityData/minnesota-state-university-moorhead'
import * as minotstateuniversity from '../../assets/universityData/minot-state-university'
import * as mississippistateuniversity from '../../assets/universityData/mississippi-state-university'
import * as mississippiuniversityforwomen from '../../assets/universityData/mississippi-university-for-women'
import * as mississippivalleystateuniversity from '../../assets/universityData/mississippi-valley-state-university'
import * as missouribaptistuniversity from '../../assets/universityData/missouri-baptist-university'
import * as missouristateuniversity from '../../assets/universityData/missouri-state-university'
import * as missouriuniversityofscienceandtechnology from '../../assets/universityData/missouri-university-of-science-and-technology'
import * as missouriwesternstateuniversity from '../../assets/universityData/missouri-western-state-university'
import * as monmouthuniversity from '../../assets/universityData/monmouth-university'
import * as montanastateuniversitybillings from '../../assets/universityData/montana-state-university-billings'
import * as montanastateuniversitynorthern from '../../assets/universityData/montana-state-university-northern'
import * as montclairstateuniversity from '../../assets/universityData/montclair-state-university'
import * as millermottecollegenorthcarolina from '../../assets/universityData/miller-motte-college-north-carolina'
import * as millermottecollegesouthcarolina from '../../assets/universityData/miller-motte-college-south-carolina'
import * as millsapscollegemississippi from '../../assets/universityData/millsaps-college-mississippi'
import * as millscollegecalifornia from '../../assets/universityData/mills-college-california'
import * as milwaukeeinstituteofartanddesign from '../../assets/universityData/milwaukee-institute-of-art-and-design'
import * as milwaukeeschoolofengineering from '../../assets/universityData/milwaukee-school-of-engineering'
import * as mississippicollegemississippi from '../../assets/universityData/mississippi-college-mississippi'
import * as missourivalleycollege from '../../assets/universityData/missouri-valley-college'
import * as mitchelltechnicalcollege from '../../assets/universityData/mitchell-technical-college'
import * as mohavecommunitycollege from '../../assets/universityData/mohave-community-college'
import * as mohawkcollegeontario from '../../assets/universityData/mohawk-college-ontario'
import * as molloycollegenewyork from '../../assets/universityData/molloy-college-new-york'
import * as monbulkcollegevictoria from '../../assets/universityData/monbulk-college-victoria'
import * as monmouthcollegeillinois from '../../assets/universityData/monmouth-college-illinois'
import * as monroecollegenewyork from '../../assets/universityData/monroe-college-new-york'
import * as montreatcollegenorthcarolina from '../../assets/universityData/montreat-college-north-carolina'
import * as montserratcollegeofartmaine from '../../assets/universityData/montserrat-college-of-art-maine'
import * as montserratcollegeofartmassachusetts from '../../assets/universityData/montserrat-college-of-art-massachusetts'
import * as mooretheologicalcollege from '../../assets/universityData/moore-theological-college'
import * as moravianuniversitypennsylvania from '../../assets/universityData/moravian-university-pennsylvania'
import * as morehousecollegegeorgia from '../../assets/universityData/morehouse-college-georgia'
import * as morgancommunitycollege from '../../assets/universityData/morgan-community-college'
import * as morganstateuniversity from '../../assets/universityData/morgan-state-university'
import * as morlingcollegenewsouthwales from '../../assets/universityData/morling-college-new-south-wales'
import * as morningsideuniversity from '../../assets/universityData/morningside-university'
import * as morrincollegequebec from '../../assets/universityData/morrin-college-quebec'
import * as morriscollegesouthcarolina from '../../assets/universityData/morris-college-south-carolina'
import * as morrisoninstituteoftechnology from '../../assets/universityData/morrison-institute-of-technology'
import * as mosmamanitoba from '../../assets/universityData/mosma-manitoba'
import * as mountainstatecollege from '../../assets/universityData/mountain-state-college'
import * as mountallisonuniversity from '../../assets/universityData/mount-allison-university'
import * as mountaloysiuscollege from '../../assets/universityData/mount-aloysius-college'
import * as mountcarmelcollegeofnursing from '../../assets/universityData/mount-carmel-college-of-nursing'
import * as mountholyokecollege from '../../assets/universityData/mount-holyoke-college'
import * as mountmartyuniversity from '../../assets/universityData/mount-marty-university'
import * as mountmaryuniversity from '../../assets/universityData/mount-mary-university'
import * as mountmercyuniversity from '../../assets/universityData/mount-mercy-university'
import * as mountroyaluniversity from '../../assets/universityData/mount-royal-university'
import * as mountsaintmarysuniversity from '../../assets/universityData/mount-saint-marys-university'
import * as mountsaintvincentuniversity from '../../assets/universityData/mount-saint-vincent-university'
import * as mountstjosephuniversity from '../../assets/universityData/mount-st-joseph-university'
import * as mountstmarysuniversity from '../../assets/universityData/mount-st-marys-university'
import * as mountvernonnazareneuniversity from '../../assets/universityData/mount-vernon-nazarene-university'
import * as mountwestcommunityandtechnicalcollege from '../../assets/universityData/mountwest-community-and-technical-college'
import * as msudenvercolorado from '../../assets/universityData/msu-denver-colorado'
import * as muhlenbergcollege from '../../assets/universityData/muhlenberg-college'
import * as multnomahuniversity from '../../assets/universityData/multnomah-university'
import * as murdochbusinessschool from '../../assets/universityData/murdoch-business-school'
import * as mureskinstitutewa from '../../assets/universityData/muresk-institute-wa'
import * as murraystatecollege from '../../assets/universityData/murray-state-college'
import * as murraystateuniversity from '../../assets/universityData/murray-state-university'
import * as muskingumuniversity from '../../assets/universityData/muskingum-university'
import * as naitalberta from '../../assets/universityData/nait-alberta'
import * as naropauniversity from '../../assets/universityData/naropa-university'
import * as nashuacommunitycollege from '../../assets/universityData/nashua-community-college'
import * as nationalaboriginalislander from '../../assets/universityData/national-aboriginal-islander'
import * as nationalcollegeofvocationaleducation from '../../assets/universityData/national-college-of-vocational-education'
import * as nationalmedicalcollege from '../../assets/universityData/national-medical-college'
import * as nationalparalegalcollege from '../../assets/universityData/national-paralegal-college'
import * as nationalparkcollege from '../../assets/universityData/national-park-college'
import * as nationaluniversitycalifornia from '../../assets/universityData/national-university-california'
import * as nationaluniversityofhealthsciences from '../../assets/universityData/national-university-of-health-sciences'
import * as naturecarecollege from '../../assets/universityData/nature-care-college'
import * as navajotechnicaluniversity from '../../assets/universityData/navajo-technical-university'
import * as navarrocollegetexas from '../../assets/universityData/navarro-college-texas'
import * as nazarenetheologicalcollege from '../../assets/universityData/nazarene-theological-college'
import * as nbcccorporateofficefredericton from '../../assets/universityData/nbcc-corporate-office-fredericton'
import * as ncktechnicalcollege from '../../assets/universityData/nck-technical-college'
import * as neathporttalbotcollegeafan from '../../assets/universityData/neath-port-talbot-college-afan'
import * as neathporttalbotcollegecolegponardawe from '../../assets/universityData/neath-port-talbot-college-coleg-ponardawe'
import * as nebraskachristiancollege from '../../assets/universityData/nebraska-christian-college'
import * as nebraskacollegeoftechnicalagriculture from '../../assets/universityData/nebraska-college-of-technical-agriculture'
import * as nebraskaindiancommunitycollege from '../../assets/universityData/nebraska-indian-community-college'
import * as nebraskamethodistcollege from '../../assets/universityData/nebraska-methodist-college'
import * as nebraskawesleyanuniversity from '../../assets/universityData/nebraska-wesleyan-university'
import * as neoshocountycommunitycollege from '../../assets/universityData/neosho-county-community-college'
import * as nepalmedicalcollege from '../../assets/universityData/nepal-medical-college'
import * as nepalgunjmedicalcollege from '../../assets/universityData/nepalgunj-medical-college'
import * as neumontcollegeofcomputerscience from '../../assets/universityData/neumont-college-of-computer-science'
import * as nevadastatecollege from '../../assets/universityData/nevada-state-college'
import * as newbrunswickbibleinstitute from '../../assets/universityData/new-brunswick-bible-institute'
import * as newbrunswickcollegeofcraftanddesign from '../../assets/universityData/new-brunswick-college-of-craft-and-design'
import * as newcollegeofflorida from '../../assets/universityData/new-college-of-florida'
import * as newenglandcollege from '../../assets/universityData/new-england-college'
import * as newjerseycityuniversity from '../../assets/universityData/new-jersey-city-university'
import * as newjerseyinstituteoftechnology from '../../assets/universityData/new-jersey-institute-of-technology'
import * as newmexicohighlandsuniversity from '../../assets/universityData/new-mexico-highlands-university'
import * as newmexicoinstituteofminingandtechnology from '../../assets/universityData/new-mexico-institute-of-mining-and-technology'
import * as newmexicojuniorcollege from '../../assets/universityData/new-mexico-junior-college'
import * as newmexicomilitaryinstitute from '../../assets/universityData/new-mexico-military-institute'
import * as newmexicostateuniversityalamogordo from '../../assets/universityData/new-mexico-state-university-alamogordo'
import * as newmexicostateuniversitycarlsbad from '../../assets/universityData/new-mexico-state-university-carlsbad'
import * as newmexicostateuniversitygrants from '../../assets/universityData/new-mexico-state-university-grants'
import * as newmexicostateuniversity from '../../assets/universityData/new-mexico-state-university'
import * as newmexicoveteransupwardbound from '../../assets/universityData/new-mexico-veterans-upward-bound'
import * as newrivercommunityandtechnicalcollege from '../../assets/universityData/new-river-community-and-technical-college'
import * as newschoolofarchitectureanddesign from '../../assets/universityData/new-school-of-architecture-and-design'
import * as newsouthwalespoliceacademy from '../../assets/universityData/new-south-wales-police-academy'
import * as newyorkcollegeofhealthprofessions from '../../assets/universityData/new-york-college-of-health-professions'
import * as newyorkfilmacademy from '../../assets/universityData/new-york-film-academy'
import * as newyorkschoolofinteriordesign from '../../assets/universityData/new-york-school-of-interior-design'
import * as newyorkuniversity from '../../assets/universityData/new-york-university'
import * as newberrycollege from '../../assets/universityData/newberry-college'
import * as newcastleuniversity from '../../assets/universityData/newcastle-university'
import * as newmancollegeireland from '../../assets/universityData/newman-college-ireland'
import * as newmantheologicalcollege from '../../assets/universityData/newman-theological-college'
import * as newmanuniversitykansas from '../../assets/universityData/newman-university-kansas'
import * as nhticoncordscommunitycollege from '../../assets/universityData/nhti-concords-community-college'
import * as niaccnorthiowaareacommunitycollege from '../../assets/universityData/niacc-north-iowa-area-community-college'
import * as niagaracollegeontario from '../../assets/universityData/niagara-college-ontario'
import * as nichollsstateuniversity from '../../assets/universityData/nicholls-state-university'
import * as nicolavalleyinstituteoftechnology from '../../assets/universityData/nicola-valley-institute-of-technology'
import * as nightingalecollege from '../../assets/universityData/nightingale-college'
import * as nipawinbiblecollege from '../../assets/universityData/nipawin-bible-college'
import * as nipissinguniversityontario from '../../assets/universityData/nipissing-university-ontario'
import * as nobelmedicalcollege from '../../assets/universityData/nobel-medical-college'
import * as nocholscollegemassachusetts from '../../assets/universityData/nochols-college-massachusetts'
import * as norquestcollegeedmontoncampus from '../../assets/universityData/norquest-college-edmonton-campus'
import * as northamericanuniversity from '../../assets/universityData/north-american-university'
import * as northarkansascollege from '../../assets/universityData/north-arkansas-college'
import * as northcarolinaagriculturalandtechnicalstateuniversity from '../../assets/universityData/north-carolina-agricultural-and-technical-state-university'
import * as northcarolinacentraluniversity from '../../assets/universityData/north-carolina-central-university'
import * as northcarolinastateuniversity from '../../assets/universityData/north-carolina-state-university'
import * as northcarolinawesleyancollege from '../../assets/universityData/north-carolina-wesleyan-college'
import * as northcentralcollegeillinois from '../../assets/universityData/north-central-college-illinois'
import * as northcentraluniversity from '../../assets/universityData/north-central-university'
import * as northdakotastateuniversity from '../../assets/universityData/north-dakota-state-university'
import * as northeastmedicalcollege from '../../assets/universityData/north-east-medical-college'
import * as northgreenvilleuniversitynorthcarolina from '../../assets/universityData/north-greenville-university-north-carolina'
import * as northgreenvilleuniversitysouthcarolina from '../../assets/universityData/north-greenville-university-south-carolina'
import * as northidahocollege from '../../assets/universityData/north-idaho-college'
import * as northislandcollege from '../../assets/universityData/north-island-college'
import * as northparkuniversity from '../../assets/universityData/north-park-university'
import * as northscotlandcollege from '../../assets/universityData/north-scotland-college'
import * as northwestcollegesaskatchewan from '../../assets/universityData/north-west-college-saskatchewan'
import * as northwestregionalcollegenorthernireland from '../../assets/universityData/north-west-regional-college-northern-ireland'
import * as northwestregionalcollegederrylondonderry from '../../assets/universityData/north-west-regional-college-derry-londonderry'
import * as northwestregionalcollegelimavady from '../../assets/universityData/north-west-regional-college-limavady'
import * as northcentraluniversityarizona from '../../assets/universityData/northcentral-university-arizona'
import * as northeastalabamacommunitycollege from '../../assets/universityData/northeast-alabama-community-college'
import * as northeasttexascommunitycollege from '../../assets/universityData/northeast-texas-community-college'
import * as northeastwisconsintechnicalcollege from '../../assets/universityData/northeast-wisconsin-technical-college'
import * as northeasternillinoisuniversity from '../../assets/universityData/northeastern-illinois-university'
import * as northeasternuniversitymassachusetts from '../../assets/universityData/northeastern-university-massachusetts'
import * as northernarizonauniversity from '../../assets/universityData/northern-arizona-university'
import * as northernillinoisuniversity from '../../assets/universityData/northern-illinois-university'
import * as northernkentuckyuniversity from '../../assets/universityData/northern-kentucky-university'
import * as northernlakescollege from '../../assets/universityData/northern-lakes-college'
import * as northernlightscollege from '../../assets/universityData/northern-lights-college'
import * as northernmichiganuniversity from '../../assets/universityData/northern-michigan-university'
import * as northernnewmexicocollege from '../../assets/universityData/northern-new-mexico-college'
import * as northernregionalcollegeballymoney from '../../assets/universityData/northern-regional-college-ballymoney'
import * as northernregionalcollegeantrim from '../../assets/universityData/northern-regional-college-antrim'
import * as northernregionalcollegelarne from '../../assets/universityData/northern-regional-college-larne'
import * as northernregionalcollegenorthernireland from '../../assets/universityData/northern-regional-college-northern-ireland'
import * as northernstateuniversity from '../../assets/universityData/northern-state-university'
import * as northernvermontuniversity from '../../assets/universityData/northern-vermont-university'
import * as northlandpioneercollege from '../../assets/universityData/northland-pioneer-college'
import * as northlandscollegesaskatchewan from '../../assets/universityData/northlands-college-saskatchewan'
import * as northpointbiblecollege from '../../assets/universityData/northpoint-bible-college'
import * as northumbriauniversity from '../../assets/universityData/northumbria-university'
import * as northwestarkansascommunitycollege from '../../assets/universityData/northwest-arkansas-community-college'
import * as northwestcareercollege from '../../assets/universityData/northwest-career-college'
import * as northwestcollegeofartanddesign from '../../assets/universityData/northwest-college-of-art-and-design'
import * as northwestcollegewyoming from '../../assets/universityData/northwest-college-wyoming'
import * as northwestiowacommunitycollege from '../../assets/universityData/northwest-iowa-community-college'
import * as northwestmissouristateuniversity from '../../assets/universityData/northwest-missouri-state-university'
import * as northwestnazareneuniversity from '../../assets/universityData/northwest-nazarene-university'
import * as northwestuniversity from '../../assets/universityData/northwest-university'
import * as northwestvistacollege from '../../assets/universityData/northwest-vista-college'
import * as northwesterncollegeiowa from '../../assets/universityData/northwestern-college-iowa'
import * as northwesternconnecticutcommunitycollege from '../../assets/universityData/northwestern-connecticut-community-college'
import * as northwesternoklahomastateuniversity from '../../assets/universityData/northwestern-oklahoma-state-university'
import * as northwesternstateuniversity from '../../assets/universityData/northwestern-state-university'
import * as northwesternuniversityillinois from '../../assets/universityData/northwestern-university-illinois'
import * as northwestshoalscommunitycollege from '../../assets/universityData/northwest-shoals-community-college'
import * as northwoodtechnicalcollege from '../../assets/universityData/northwood-technical-college'
import * as northwooduniversity from '../../assets/universityData/northwood-university'
import * as norwalkcommunitycollege from '../../assets/universityData/norwalk-community-college'
import * as norwichuniversity from '../../assets/universityData/norwich-university'
import * as nossicollegeofart from '../../assets/universityData/nossi-college-of-art'
import * as notredamecollege from '../../assets/universityData/notre-dame-college'
import * as notredameofmarylanduniversity from '../../assets/universityData/notre-dame-of-maryland-university'
import * as nottinghamtrentuniversity from '../../assets/universityData/nottingham-trent-university'
import * as novascotiaagriculturalcollege from '../../assets/universityData/nova-scotia-agricultural-college'
import * as novascotiateacherscollege from '../../assets/universityData/nova-scotia-teachers-college'
import * as novasouthwesternuniversity from '../../assets/universityData/nova-southwestern-university'
import * as nptcgroupofcollege from '../../assets/universityData/nptc-group-of-college'
import * as nrcballymena from '../../assets/universityData/nrc-ballymena'
import * as nscaduniversity from '../../assets/universityData/nscad-university'
import * as nscccentreofgeographicsciences from '../../assets/universityData/nscc-centre-of-geographic-sciences'
import * as nsccinstituteoftechnologycampus from '../../assets/universityData/nscc-institute-of-technology-campus'
import * as nscecenovascotia from '../../assets/universityData/nscece-nova-scotia'
import * as nuetahidatsasahnishnhscommunitycollege from '../../assets/universityData/nueta-hidatsa-sahnish-nhs-community-college'
import * as nunavutarcticcollege from '../../assets/universityData/nunavut-arctic-college'
import * as nunezcommunitycollege from '../../assets/universityData/nunez-community-college'
import * as nungalinyacollege from '../../assets/universityData/nungalinya-college'
import * as nyackcollege from '../../assets/universityData/nyack-college'
import * as oaklandcityuniversity from '../../assets/universityData/oakland-city-university'
import * as oaklanduniversity from '../../assets/universityData/oakland-university'
import * as oberlincollege from '../../assets/universityData/oberlin-college'
import * as ocaduniversity from '../../assets/universityData/ocad-university'
import * as occidentalcollege from '../../assets/universityData/occidental-college'
import * as oceancountycollege from '../../assets/universityData/ocean-county-college'
import * as odessacollege from '../../assets/universityData/odessa-college'
import * as oglethorpeuniversity from '../../assets/universityData/oglethorpe-university'
import * as ohiobusinesscollege from '../../assets/universityData/ohio-business-college'
import * as ohiochristianuniversity from '../../assets/universityData/ohio-christian-university'
import * as ohiodominicanuniversity from '../../assets/universityData/ohio-dominican-university'
import * as ohionorthernuniversity from '../../assets/universityData/ohio-northern-university'
import * as ohiostateuniversity from '../../assets/universityData/ohio-state-university'
import * as ohiotechnicalcollege from '../../assets/universityData/ohio-technical-college'
import * as ohiouniversity from '../../assets/universityData/ohio-university'
import * as ohiovalleycollegeoftechnology from '../../assets/universityData/ohio-valley-college-of-technology'
import * as ohiovalleyuniversity from '../../assets/universityData/ohio-valley-university'
import * as ohiovalleyuniversitywestvirginia from '../../assets/universityData/ohio-valley-university-west-virginia'
import * as ohiowesleyanuniversity from '../../assets/universityData/ohio-wesleyan-university'
import * as okanagancollegekelownacampus from '../../assets/universityData/okanagan-college-kelowna-campus'
import * as oklahomacityuniversity from '../../assets/universityData/oklahoma-city-university'
import * as oklahomastateuniversity from '../../assets/universityData/oklahoma-state-university'
import * as oklahomawesleyanuniversity from '../../assets/universityData/oklahoma-wesleyan-university'
import * as olddominionuniversity from '../../assets/universityData/old-dominion-university'
import * as oldsuncommunitycollege from '../../assets/universityData/old-sun-community-college'
import * as oldscollegealberta from '../../assets/universityData/olds-college-alberta'
import * as olincollegeofengineering from '../../assets/universityData/olin-college-of-engineering'
import * as olivetcollegemichigan from '../../assets/universityData/olivet-college-michigan'
import * as olivetnazareneuniversity from '../../assets/universityData/olivet-nazarene-university'
import * as ontariotechuniversity from '../../assets/universityData/ontario-tech-university'
import * as oralrobertsuniversity from '../../assets/universityData/oral-roberts-university'
import * as orangecoastcollege from '../../assets/universityData/orange-coast-college'
import * as oregoninstituteoftechnology from '../../assets/universityData/oregon-institute-of-technology'
import * as oregonstateuniversity from '../../assets/universityData/oregon-state-university'
import * as otiscollegeofartanddesign from '../../assets/universityData/otis-college-of-art-and-design'
import * as ottawauniversity from '../../assets/universityData/ottawa-university'
import * as otterbeinuniversity from '../../assets/universityData/otterbein-university'
import * as ouachitabaptistuniversity from '../../assets/universityData/ouachita-baptist-university'
import * as oultoncollegemoncton from '../../assets/universityData/oulton-college-moncton'
import * as ourladyofthelakeuniversity from '../../assets/universityData/our-lady-of-the-lake-university'
import * as ozarkacollegearkansas from '../../assets/universityData/ozarka-college-arkansas'
import * as paceuniversitynewyork from '../../assets/universityData/pace-university-new-york'
import * as pacificlutheranuniversity from '../../assets/universityData/pacific-lutheran-university'
import * as pacificnorthwestcollegeofart from '../../assets/universityData/pacific-northwest-college-of-art'
import * as pacificrimchristianuniversity from '../../assets/universityData/pacific-rim-christian-university'
import * as pacificstatesuniversity from '../../assets/universityData/pacific-states-university'
import * as pacificunioncollege from '../../assets/universityData/pacific-union-college'
import * as palmbeachatlanticuniversity from '../../assets/universityData/palm-beach-atlantic-university'
import * as palmercollegeofchiropracticmaincampus from '../../assets/universityData/palmer-college-of-chiropractic-main-campus'
import * as paloaltocollegetexas from '../../assets/universityData/palo-alto-college-texas'
import * as panolacollegetexas from '../../assets/universityData/panola-college-texas'
import * as paradisevalleycommunitycollege from '../../assets/universityData/paradise-valley-community-college'
import * as parisjuniorcollegetexas from '../../assets/universityData/paris-junior-college-texas'
import * as parkeruniversitycampus from '../../assets/universityData/parker-university-campus'
import * as parklandcollegemaincampus from '../../assets/universityData/parkland-college-main-campus'
import * as parklandcollegetradesandtechnologycentre from '../../assets/universityData/parkland-college-trades-and-technology-centre'
import * as parklandcollegekelvington from '../../assets/universityData/parkland-college-kelvington'
import * as paulquinncollegetexas from '../../assets/universityData/paul-quinn-college-texas'
import * as pavillonjraymondfrenette from '../../assets/universityData/pavillon-j-raymond-frenette'
import * as peaceriverbibleinstitute from '../../assets/universityData/peace-river-bible-institute'
import * as pearsoncollegeuwc from '../../assets/universityData/pearson-college-uwc'
import * as pembrokescollegewales from '../../assets/universityData/pembrokes-college-wales'
import * as pennstateuniversity from '../../assets/universityData/penn-state-university'
import * as pennsylvaniacollegeofartanddesign from '../../assets/universityData/pennsylvania-college-of-art-and-design'
import * as pennsylvaniacollegeofhealthsciences from '../../assets/universityData/pennsylvania-college-of-health-sciences'
import * as pennsylvaniacollegeoftechnology from '../../assets/universityData/pennsylvania-college-of-technology'
import * as pennsylvaniahighlandscommunitycollege from '../../assets/universityData/pennsylvania-highlands-community-college'
import * as pepperdineuniversitycalifornia from '../../assets/universityData/pepperdine-university-california'
import * as perrytechnicalinstitutewashington from '../../assets/universityData/perry-technical-institute-washington'
import * as perthbiblecollegewesternaustralia from '../../assets/universityData/perth-bible-college-western-australia'
import * as perustatecollegenebraska from '../../assets/universityData/peru-state-college-nebraska'
import * as pfeifferuniversity from '../../assets/universityData/pfeiffer-university'
import * as philandersmithcollegearkansas from '../../assets/universityData/philander-smith-college-arkansas'
import * as phillipscommunitycollegeoftheuniversity from '../../assets/universityData/phillips-community-college-of-the-university'
import * as phoenixcollegearizona from '../../assets/universityData/phoenix-college-arizona'
import * as piedmonttechnicalcollege from '../../assets/universityData/piedmont-technical-college'
import * as pierpontcommunityandtechnicalcollege from '../../assets/universityData/pierpont-community-and-technical-college'
import * as pimamedicalinstitutelasvegas from '../../assets/universityData/pima-medical-institute-las-vegas'
import * as pimamedicalinstitutearizona from '../../assets/universityData/pima-medical-institute-arizona'
import * as pittsburgstateuniversity from '../../assets/universityData/pittsburg-state-university'
import * as pitzercollegecalifornia from '../../assets/universityData/pitzer-college-california'
import * as plazacollegenewyork from '../../assets/universityData/plaza-college-new-york'
import * as plymouthstateuniversity from '../../assets/universityData/plymouth-state-university'
import * as pointlomanazareneuniversitycalifornia from '../../assets/universityData/point-loma-nazarene-university-california'
import * as pointuniversitygeorgia from '../../assets/universityData/point-university-georgia'
import * as polytechnicuniversityorlandocampus from '../../assets/universityData/polytechnic-university-orlando-campus'
import * as purdueuniversityfortwayne from '../../assets/universityData/purdue-university-fort-wayne'
import * as pomonacollegecalifornia from '../../assets/universityData/pomona-college-california'
import * as pontificalcollegejosephinum from '../../assets/universityData/pontifical-college-josephinum'
import * as portagecollegelaclabichecampus from '../../assets/universityData/portage-college-lac-la-biche-campus'
import * as portervillecollegecalifornia from '../../assets/universityData/porterville-college-california'
import * as portlandstateuniversity from '../../assets/universityData/portland-state-university'
import * as postuniversityconnecticut from '../../assets/universityData/post-university-connecticut'
import * as prairiecollegealberta from '../../assets/universityData/prairie-college-alberta'
import * as prairieviewaandmuniversity from '../../assets/universityData/prairie-view-aandm-university'
import * as prattcommunitycollegekansas from '../../assets/universityData/pratt-community-college-kansas'
import * as prattinstitutenewyork from '../../assets/universityData/pratt-institute-new-york'
import * as presbyteriancollege from '../../assets/universityData/presbyterian-college'
import * as prescottcollegearizona from '../../assets/universityData/prescott-college-arizona'
import * as princetonuniversity from '../../assets/universityData/princeton-university'
import * as presentationcollegesouthdakota from '../../assets/universityData/presentation-college-south-dakota'
import * as providencecollegerhodeisland from '../../assets/universityData/providence-college-rhode-island'
import * as providenceuniversity from '../../assets/universityData/providence-university'
import * as provocollegeutah from '../../assets/universityData/provo-college-utah'
import * as pueblocommunitycollegecolorado from '../../assets/universityData/pueblo-community-college-colorado'
import * as purdueuniversityindiana from '../../assets/universityData/purdue-university-indiana'
import * as qimrberghofermedicalresearchinstitute from '../../assets/universityData/qimr-berghofer-medical-research-institute'
import * as queenmaryuniversityoflondon from '../../assets/universityData/queen-mary-university-of-london'
import * as queensuniversitybelfast from '../../assets/universityData/queens-university-belfast'
import * as queensuniversityofcharlotte from '../../assets/universityData/queens-university-of-charlotte'
import * as questuniversitycanada from '../../assets/universityData/quest-university-canada'
import * as quincycollegemassachusetts from '../../assets/universityData/quincy-college-massachusetts'
import * as quincyuniversityillinois from '../../assets/universityData/quincy-university-illinois'
import * as quinnipiacuniversity from '../../assets/universityData/quinnipiac-university'
import * as qutgardenspointcampus from '../../assets/universityData/qut-gardens-point-campus'
import * as racmavictoria from '../../assets/universityData/racma-victoria'
import * as ramapocollegeofnewjersey from '../../assets/universityData/ramapo-college-of-new-jersey'
import * as randalluniversity from '../../assets/universityData/randall-university'
import * as rangercollegetexas from '../../assets/universityData/ranger-college-texas'
import * as rankentechnicalcollegemissouri from '../../assets/universityData/ranken-technical-college-missouri'
import * as rasmussenuniversityfargo from '../../assets/universityData/rasmussen-university-fargo'
import * as rasmussenuniversitywisconsin from '../../assets/universityData/rasmussen-university-wisconsin'
import * as redcrowcommunitycollege from '../../assets/universityData/red-crow-community-college'
import * as reddeerpolytechnicuniversity from '../../assets/universityData/red-deer-polytechnic-university'
import * as redrivercollegegimli from '../../assets/universityData/red-river-college-gimli'
import * as redrivercollegeadultlearningcentre from '../../assets/universityData/red-river-college-adult-learning-centre'
import * as redrivercollegepeguis from '../../assets/universityData/red-river-college-peguis'
import * as redrivercollegeprincessstreet from '../../assets/universityData/red-river-college-princess-street'
import * as redrivercollegesteinbachcommunity from '../../assets/universityData/red-river-college-steinbach-community'
import * as redrivercollegesaatcsouthport from '../../assets/universityData/red-river-college-saatc-southport'
import * as redrivercollegesaatcwinnipeg from '../../assets/universityData/red-river-college-saatc-winnipeg'
import * as reedcollegeoregon from '../../assets/universityData/reed-college-oregon'
import * as regentcollegevancouver from '../../assets/universityData/regent-college-vancouver'
import * as regentuniversityvirginia from '../../assets/universityData/regent-university-virginia'
import * as regiscollegemassachusetts from '../../assets/universityData/regis-college-massachusetts'
import * as regisuniversity from '../../assets/universityData/regis-university'
import * as remingtoncollegegreenspointcampus from '../../assets/universityData/remington-college-greenspoint-campus'
import * as remingtoncollegelouisiana from '../../assets/universityData/remington-college-louisiana'
import * as remingtoncollegetennessee from '../../assets/universityData/remington-college-tennessee'
import * as rhodeislandcollege from '../../assets/universityData/rhode-island-college'
import * as rhodeislandschoolofdesign from '../../assets/universityData/rhode-island-school-of-design'
import * as rhodescollegetennessee from '../../assets/universityData/rhodes-college-tennessee'
import * as riceuniversity from '../../assets/universityData/rice-university'
import * as rideruniversity from '../../assets/universityData/rider-university'
import * as ridleycollegevictoria from '../../assets/universityData/ridley-college-victoria'
import * as ringlingcollegeofartanddesign from '../../assets/universityData/ringling-college-of-art-and-design'
import * as riosaladocollegearizona from '../../assets/universityData/rio-salado-college-arizona'
import * as riponcollegewisconsin from '../../assets/universityData/ripon-college-wisconsin'
import * as rivervalleycommunitycollege from '../../assets/universityData/river-valley-community-college'
import * as rivieruniversity from '../../assets/universityData/rivier-university'
import * as robertmorrisuniversity from '../../assets/universityData/robert-morris-university'
import * as robertsoncollegemanitoba from '../../assets/universityData/robertson-college-manitoba'
import * as rockforduniversity from '../../assets/universityData/rockford-university'
import * as rockhurstuniversity from '../../assets/universityData/rockhurst-university'
import * as rockymountaincollegeofartdesign from '../../assets/universityData/rocky-mountain-college-of-art-design'
import * as rockymountaincollegemontana from '../../assets/universityData/rocky-mountain-college-montana'
import * as rogerwilliamsuniversity from '../../assets/universityData/roger-williams-university'
import * as rogersstateuniversity from '../../assets/universityData/rogers-state-university'
import * as rolinscollegeflorida from '../../assets/universityData/rolins-college-florida'
import * as rooseveltuniversity from '../../assets/universityData/roosevelt-university'
import * as rosehulmaninstituteoftechnology from '../../assets/universityData/rose-hulman-institute-of-technology'
import * as rosemountcollegepennsylvania from '../../assets/universityData/rosemount-college-pennsylvania'
import * as rowanuniversity from '../../assets/universityData/rowan-university'
import * as roxburycommunitycollege from '../../assets/universityData/roxbury-community-college'
import * as royalaustralianandnewzealandcollege from '../../assets/universityData/royal-australian-and-new-zealand-college'
import * as royalhollowayengland from '../../assets/universityData/royal-holloway-england'
import * as royalmilitarycollegeofcanada from '../../assets/universityData/royal-military-college-of-canada'
import * as royalwelshcollege from '../../assets/universityData/royal-welsh-college'
import * as rrcpolytechlanguagetrainingcentre from '../../assets/universityData/rrc-polytech-language-training-centre'
import * as rrcpolytechportagecampus from '../../assets/universityData/rrc-polytech-portage-campus'
import * as rrcpolytechsteinbachcampus from '../../assets/universityData/rrc-polytech-steinbach-campus'
import * as rrcpolytechwinnipeg from '../../assets/universityData/rrc-polytech-winnipeg'
import * as rustcollegemississippi from '../../assets/universityData/rust-college-mississippi'
import * as rutgersuniversitynewarkcampus from '../../assets/universityData/rutgers-university-newark-campus'
import * as rutgersuniversitycamden from '../../assets/universityData/rutgers-university-camden'
import * as rutgersnewbrunswick from '../../assets/universityData/rutgers-new-brunswick'
import * as sacredheartuniversity from '../../assets/universityData/sacred-heart-university'
import * as saginawvalleystateuniversity from '../../assets/universityData/saginaw-valley-state-university'
import * as saintanselmcollege from '../../assets/universityData/saint-anselm-college'
import * as saintaugustinesuniversity from '../../assets/universityData/saint-augustines-university'
import * as saintcloudstateuniversity from '../../assets/universityData/saint-cloud-state-university'
import * as saintelizabethuniversity from '../../assets/universityData/saint-elizabeth-university'
import * as saintfrancisuniversity from '../../assets/universityData/saint-francis-university'
import * as sainthermantheologicalseminary from '../../assets/universityData/saint-herman-theological-seminary'
import * as saintjohnsuniversity from '../../assets/universityData/saint-johns-university'
import * as saintjosephabbeyandseminarycollege from '../../assets/universityData/saint-joseph-abbey-and-seminary-college'
import * as saintjosephscollegeofmaine from '../../assets/universityData/saint-josephs-college-of-maine'
import * as saintjosephsuniversity from '../../assets/universityData/saint-josephs-university'
import * as saintleouniversity from '../../assets/universityData/saint-leo-university'
import * as saintlouisuniversitymissouri from '../../assets/universityData/saint-louis-university-missouri'
import * as saintmartinsuniversity from '../../assets/universityData/saint-martins-university'
import * as saintmaryscollegeofcalifornia from '../../assets/universityData/saint-marys-college-of-california'
import * as saintmarysuniversityofminnesota from '../../assets/universityData/saint-marys-university-of-minnesota'
import * as saintmarysuniversitynovascotia from '../../assets/universityData/saint-marys-university-nova-scotia'
import * as saintpauluniversity from '../../assets/universityData/saint-paul-university'
import * as saintpetersuniversity from '../../assets/universityData/saint-peters-university'
import * as saintvincentcollege from '../../assets/universityData/saint-vincent-college'
import * as saintvladimirscollege from '../../assets/universityData/saint-vladimirs-college'
import * as saintxavieruniversity from '../../assets/universityData/saint-xavier-university'
import * as salemcollegenorthcarolina from '../../assets/universityData/salem-college-north-carolina'
import * as salemstateuniversitymaine from '../../assets/universityData/salem-state-university-maine'
import * as salemstateuniversitymassachusetts from '../../assets/universityData/salem-state-university-massachusetts'
import * as salemuniversitywestvirginia from '../../assets/universityData/salem-university-west-virginia'
import * as salinaareatechnicalcollege from '../../assets/universityData/salina-area-technical-college'
import * as salisburyuniversity from '../../assets/universityData/salisbury-university'
import * as salvereginauniversity from '../../assets/universityData/salve-regina-university'
import * as samhoustonstateuniversity from '../../assets/universityData/sam-houston-state-university'
import * as samforduniversity from '../../assets/universityData/samford-university'
import * as samuelmerrittuniversity from '../../assets/universityData/samuel-merritt-university'
import * as sanantoniocollege from '../../assets/universityData/san-antonio-college'
import * as sandiegostateuniversity from '../../assets/universityData/san-diego-state-university'
import * as sanfranciscostateuniversity from '../../assets/universityData/san-francisco-state-university'
import * as sanignaciouniversity from '../../assets/universityData/san-ignacio-university'
import * as sanjosestateuniversity from '../../assets/universityData/san-jose-state-university'
import * as oakwooduniversityalabama from '../../assets/universityData/oakwood-university-alabama'
import * as sanjuancollegenewmexico from '../../assets/universityData/san-juan-college-new-mexico'
import * as sansistocollegequeensland from '../../assets/universityData/san-sisto-college-queensland'
import * as santaclarauniversity from '../../assets/universityData/santa-clara-university'
import * as santafecollegeflorida from '../../assets/universityData/santa-fe-college-florida'
import * as santafecommunitycollege from '../../assets/universityData/santa-fe-community-college'
import * as santiagocanyoncollege from '../../assets/universityData/santiago-canyon-college'
import * as sarahlawrencecollege from '../../assets/universityData/sarah-lawrence-college'
import * as saskatchewanindianinstituteoftechnologies from '../../assets/universityData/saskatchewan-indian-institute-of-technologies'
import * as saskatchewaninstituteofappliedscienceandtechnology from '../../assets/universityData/saskatchewan-institute-of-applied-science-and-technology'
import * as saskatchewanpolytechnic from '../../assets/universityData/saskatchewan-polytechnic'
import * as saultcollegeontario from '../../assets/universityData/sault-college-ontario'
import * as schillerinternationaluniversity from '../../assets/universityData/schiller-international-university'
import * as schoolofvisualarts from '../../assets/universityData/school-of-visual-arts'
import * as schreineruniversity from '../../assets/universityData/schreiner-university'
import * as scottsdalecommunitycollege from '../../assets/universityData/scottsdale-community-college'
import * as scrippscollegecalifornia from '../../assets/universityData/scripps-college-california'
import * as sealcovecampus from '../../assets/universityData/seal-cove-campus'
import * as seattlepacificuniversity from '../../assets/universityData/seattle-pacific-university'
import * as seattleuniversity from '../../assets/universityData/seattle-university'
import * as seminolestatecollege from '../../assets/universityData/seminole-state-college'
import * as setonhalluniversitynewjersey from '../../assets/universityData/seton-hall-university-new-jersey'
import * as setonhilluniversitypennsylvania from '../../assets/universityData/seton-hill-university-pennsylvania'
import * as sewardcountycommunitycollege from '../../assets/universityData/seward-county-community-college'
import * as shafstoninternationalcollege from '../../assets/universityData/shafston-international-college'
import * as shaheedmonsuralimedicalcollege from '../../assets/universityData/shaheed-monsur-ali-medical-college'
import * as shawuniversity from '../../assets/universityData/shaw-university'
import * as shawneestateuniversity from '../../assets/universityData/shawnee-state-university'
import * as sheltonstatecommunitycollege from '../../assets/universityData/shelton-state-community-college'
import * as shepherduniversity from '../../assets/universityData/shepherd-university'
import * as sheridancollegewyoming from '../../assets/universityData/sheridan-college-wyoming'
import * as shoalhavencommunitycollege from '../../assets/universityData/shoalhaven-community-college'
import * as shoalhavenmarineandfreshwatercentre from '../../assets/universityData/shoalhaven-marine-and-freshwater-centre'
import * as shoalhavenrivercollege from '../../assets/universityData/shoalhaven-river-college'
import * as shortercollegearkansas from '../../assets/universityData/shorter-college-arkansas'
import * as sierranevadauniversity from '../../assets/universityData/sierra-nevada-university'
import * as simmonsuniversity from '../../assets/universityData/simmons-university'
import * as simpsoncollegeiowa from '../../assets/universityData/simpson-college-iowa'
import * as sintegleskauniversity from '../../assets/universityData/sinte-gleska-university'
import * as sittingbullcollege from '../../assets/universityData/sitting-bull-college'
import * as smithcollegemassachusetts from '../../assets/universityData/smith-college-massachusetts'
import * as sneadstatecommunitycollege from '../../assets/universityData/snead-state-community-college'
import * as soasuniversityoflondon from '../../assets/universityData/soas-university-of-london'
import * as sofiauniversity from '../../assets/universityData/sofia-university'
import * as sokauniversityofamerica from '../../assets/universityData/soka-university-of-america'
import * as southarkansascommunitycollege from '../../assets/universityData/south-arkansas-community-college'
import * as southcarolinastateuniversity from '../../assets/universityData/south-carolina-state-university'
import * as southcoastcolleges from '../../assets/universityData/south-coast-colleges'
import * as southcollegetennessee from '../../assets/universityData/south-college-tennessee'
import * as southdakotamines from '../../assets/universityData/south-dakota-mines'
import * as southdakotastateuniversity from '../../assets/universityData/south-dakota-state-university'

export {

    //amityglobalbusinessschool,
    //amityinstituteofinformationtechnologymumbai,
    bridgetowninternationaluniversity,
    avicennatajikstatemedicaluniversity,
    alteuniversitygeorgia,
    caspianinternationalschoolofmedicine,
    universityoftrento,
    ismuniversityofmanagementandeconomics,
    allindiainstituteofmedicalsciencesaiimsnewdelhi,
    loughboroughuniversity,
    grigolrobakidzeuniversity,
    universityofsuffolk,
    poloniauniversity,
    rwthaachenuniversity,
    heidelberguniversity,
    heriotwattuniversity,
    eotvosloranduniversity,
    dhakanationalmedicalcollege,
    universityofbonn,
    northeasternfederaluniversity,
    nationalaviationuniversity,
    jalalabadragibrabeyamedicalcollege,
    vinnytsianationaltechnicaluniversity,
    kazanstatemedicaluniversity,
    iliastateuniversity,
    akakitseretelistateuniversity,
    poznanuniversityoftechnology,
    universityofsantotomas,
    tashkentstatedentalinstitute,
    southuralstateuniversity,
    samarkandstatemedicalinstitute,
    manilacentraluniversity,
    ourladyoffatimauniversity,
    nanjingmedicaluniversity,
    lyceumnorthwesternuniversity,
    kyrgyzstatemedicalacademy,
    europeanuniversitygeorgia,
    karlsruheinstituteoftechnology,
    bharatividyapeethdeemeduniversitypune,
    lvivpolytechnicnationaluniversity,
    jiangsuuniversity,
    washingtonsycipgraduateschoolofbusiness,
    moscowstateuniversityoffinechemicaltechnologies,
    ramonvdelrosariocollegeofbusiness,
    uvgullascollegeofmedicine,
    moscowschoolofmanagementskolkovo,
    newcollegedurham,
    londonschoolofeconomicsandpoliticalsciencelondon,
    manipalcollegeofmedicalsciences,
    liceocollegeofmedicine,
    liverpoolhopeuniversity,
    kathmandumedicalcollege,
    kharkivstateacademyofdesignandarts,
    emilioaguinaldocollegemanila,
    henleybusinessschool,
    brokenshirecollegeschoolofmedicine,
    davaomedicalschoolfoundation,
    asianmedicalinstitute,
    belfastmetropolitancollege,
    universityofsalford,
    asianinstitutemanagementphilippines,
    romebusinessschool,
    universityofpadua,
    amecbicolchristiancollegeofmedicine,
    easteuropeanuniversity,
    ivanofrankivsknationalmedicaluniversity,
    rostovstatemedicaluniversity,
    izhevskstatemedicalacademy,
    voronezhstatemedicaluniversity,
    wroclawuniversityoftechnology,
    universityofulm,
    usbanglamedicalcollege,
    universityofoxford,
    universityofsurrey,
    trakiauniversity,
    universityoflincoln,
    ternopilnationalmedicaluniversity,
    theuniversityoflaw,
    tbilisistatemedicaluniversity,
    tairunnessamemorialmedicalcollege,
    tallinnhealthcarecollege,
    sheridancollege,
    saratovstatemedicaluniversity,
    penzastatemedicaluniversity,
    russianpresidentialacademyofnationaleconomyandpublicadministration,
    novosibirskstateuniversity,
    novosibirskstatetechnicaluniversity,
    pacificstatemedicaluniversity,
    munichbusinessschool,
    mcmasteruniversity,
    medicaluniversityofbialystok,
    budapestuniversityoftechnologyandeconomics,
    lvivbusinessschoolofukrainiancatholicuniversity,
    maristateuniversity,
    lambtoncollege,
    eubusinessschoolmunich,
    fanshawecollege,
    dagestanstatemedicaluniversity,
    dalhousieuniversity,
    chechenstateuniversity,
    camosuncollege,
    universityofgeorgiatbilisi,
    bocconiuniversity,
    bruneluniversitylondon,
    universityofpisa,
    moscowaviationinstitute,
    tarasshevchenkonationaluniversityofkyiv,
    tashkentmedicalacademy,
    stavropolstatemedicaluniversity,
    szentistvanuniversity,
    semeystatemedicaluniversity,
    kemerovostatemedicaluniversity,
    kyrgyzrussianslavicuniversity,
    estonianacademyofarts,
    geomedistateuniversity,
    vistulauniversity,
    cardiffmetropolitanuniversity,
    cebuinstituteofmedicine,
    bppuniversity,
    universityofmannheim,
    universityofmiskolc,
    universityofbedfordshire,
    universityofcambridge,
    lodzuniversityoftechnology,
    shivajiuniversitykolhapur,
    southwesternuniversityphinma,
    newvisionuniversity,
    shahjalaluniversityofscienceandtechnology,
    lomonosovmoscowstateuniversity,
    middlesexuniversitylondon,
    lomonosovmoscowstateuniversitybusinessschool,
    uibinternationalmedicalschool,
    kharkivinternationalmedicaluniversity,
    kharkivnationaluniversityofradioelectronics,
    kingstonuniversitylondon,
    itmouniversity,
    kazakhmedicaluniversityofcontinuingeducation,
    ukrainianstatechemicaltechnologyuniversity,
    baumanmoscowstatetechnicaluniversity,
    chuvashstateuniversity,
    universityofsussex,
    royalcollegeofart,
    tomskpolytechnicuniversity,
    ningxiauniversity,
    tianjinmedicaluniversity,
    shahabuddinmedicalcollege,
    georgianamericanuniversity,
    kazakhnationalmedicaluniversity,
    armenianmedicalinstitute,
    collegiumdavinci,
    wuhanuniversity,
    vilniauskolegijauniversityofappliedsciences,
    warsawuniversityoftechnologybusinessschool,
    universityofsouthwales,
    universityoftraditionalmedicine,
    universityofmanchester,
    universityofpavia,
    universityofrajshahi,
    universityofnorthernphilippines,
    universityofedinburgh,
    transportandtelecommunicationinstitute,
    symbiosisinternationaluniversitysiupune,
    tambovstateuniversity,
    stpetersburgstatepediatricmedicaluniversity,
    stpauluniversityphilippines,
    shandonguniversity,
    sichuanuniversity,
    poltavastatemedicalanddentaluniversity,
    samarastateaerospaceuniversity,
    samarastatemedicaluniversity,
    queensuniversity,
    permstateagrotechnologicaluniversity,
    petromohylablackseanationaluniversity,
    petreshotadzetbilisimedicalacademy,
    northossetianstatemedicalacademy,
    novosibirsknationalresearchstateuniversity,
    moscowpowerengineeringinstitute,
    narseemonjeeinstituteofmanagementstudiesnmimsmumbai,
    moscowinstituteofphysicsandtechnology,
    medicaluniversityoflodz,
    mkhitargosharmenianrussianinternationaluniversity,
    kyivnationaluniversityofcultureandarts,
    leedsbeckettuniversity,
    kingscollegelondon,
    kokshetaustateuniversity,
    kharkivstateacademyofculture,
    khersonnationaltechnicaluniversity,
    kharkivnationalmedicaluniversity,
    karagandastatemedicaluniversity,
    kazanfederaluniversity,
    irkutsknationalresearchtechnicaluniversity,
    jamiamilliaislamiadelhi,
    internationalschoolofmanagementdortmund,
    gurugobindsinghindraprasthauniversitydelhi,
    grodnostatemedicaluniversity,
    esslingenuniversityofappliedsciences,
    firstmoscowstatemedicaluniversity,
    davidagmashenebeliuniversityofgeorgia,
    donbassstateengineeringacademy,
    cityuniversityoflondon,
    dalianmedicaluniversity,
    christuniversitybangalore,
    centralphilippineuniversity,
    chongqingmedicaluniversity,
    bathspauniversity,
    carlbenzschoolofengineering,
    andijanstatemedicalinstitute,
    angelesuniversityfoundation,
    alfarabikazakhnationaluniversity,
    amaschoolofmedicine,
    yorkstjohnuniversity,
    vinnitsanationalmedicaluniversity,
    warsawschoolofeconomicssgh,
    universityofeconomicsinkatowice,
    universityofgloucestershire,
    ulyanovskstateuniversity,
    tverstatemedicaluniversity,
    ufastateaviationtechnicaluniversity,
    technischehochschuleingolstadt,
    sumystateuniversity,
    northcaucasusfederaluniversity,
    pavlovfirstsaintpetersburgstatemedicaluniversity,
    moscowstateuniversityofcivilengineering,
    nationaluniversityofscienceandtechnologymisis,
    kremenchukstatetechnicaluniversity,
    luganskstatemedicaluniversity,
    kazakhrussianmedicaluniversity,
    irkutskstatemedicaluniversity,
    jagiellonianuniversitymedicalcollege,
    davidtvildianimedicaluniversity,
    bangladeshuniversityofprofessionals,
    fudanuniversity,
    astanamedicaluniversity,
    astrakhanstatemedicaluniversity,
    zaporizhzhiastateengineeringacademy,
    zhejiangmedicaluniversity,
    universityofwindsor,
    yerevanstatemedicaluniversity,
    tbilisiopenteachinguniversity,
    universityofcologne,
    ryazanstatemedicaluniversity,
    lvivnationalacademyofarts,
    odessanationalmedicaluniversity,
    johannesgutenberguniversitymainz,
    klaipedauniversity,
    bukharastatemedicalinstitute,
    caucasusinternationaluniversity,
    ivanejavakhishvilitbilisistateuniversity,
    carletonuniversity,
    westkazakhstanmaratospanovstatemedicaluniversity,
    yerevanhaybusakuniversity,
    budapestmetropolitanuniversity,
    xianjiaotonguniversity,
    universityofwarwick,
    uralstatemedicaluniversity,
    universityofdhaka,
    universityofstuttgart,
    tyumenstatemedicaluniversity,
    universityofdebrecen,
    southernmedicaluniversity,
    silesianuniversityoftechnology,
    sofiamedicaluniversity,
    patanacademyofhealthsciences,
    russiannationalresearchmedicaluniversity,
    oshstateuniversity,
    medicaluniversityofpleven,
    omskstatemedicaluniversity,
    kubanstatemedicaluniversity,
    lazarskiuniversity,
    kalmykstateuniversity,
    kharkivnationaluniversityofarts,
    guangximedicaluniversity,
    humboldtuniversityofberlin,
    gomelstatemedicaluniversity,
    gdanskmedicaluniversity,
    flameuniversitypune,
    fareasternfederaluniversity,
    cracowuniversityoftechnology,
    bashkirstatemedicaluniversity,
    yaroslavlstatemedicaluniversity,
    warsawuniversityoftechnology,
    volgogradstatemedicaluniversity,
    vnkarazinkharkivnationaluniversity,
    vitebskstatemedicaluniversity,
    universityofwarmiaandmazury,
    universityofstandrews,
    universityofsaskatchewan,
    universityofperpetualhelpsystemdalta,
    universityofottawa,
    universityoflatvia,
    universityofbristol,
    stterezamedicaluniversity,
    universityofbradford,
    simonfraseruniversity,
    risebauniversityofbusinessartsandtechnology,
    ryersonuniversity,
    reutlingenuniversity,
    poznanuniversityofmedicalscience,
    northkazakhstanstateuniversity,
    orenburgstatemedicaluniversity,
    orelstateuniversity,
    nizhnynovgorodstatetechnicaluniversity,
    nicolauscopernicusuniversity,
    moscowuniversitytouro,
    medicaluniversityofwarsaw,
    medicaluniversityofsilesia,
    medicaluniversityoflublin,
    londonmetropolitanuniversity,
    kyivmedicaluniversityofuafmkiev,
    kabardinobalkarianstateuniversity,
    jinanuniversity,
    jilinuniversity,
    georgiannationaluniversityseu,
    gdanskuniversityoftechnology,
    durhamuniversity,
    danylohalytskylvivstatemedicaluniversity,
    crimeanfederaluniversity,
    cherkasystatetechnologicaluniversity,
    bukovinianstatemedicaluniversity,
    capitalmedicaluniversity,
    belgorodstateuniversity,
    aberystwythuniversity,
    xinjianguniversity,
    yangzhouuniversity,
    universityofwolverhampton,
    universityofalberta,
    universitycanadawest,
    tribhuvanuniversity,
    tbilisipublicuniversitymetekhi,
    tallinnuniversityoftechnology,
    smolenskstatemedicaluniversity,
    pskovstateuniversity,
    pskovstatepolytechnicinstitute,
    plovdivmedicaluniversity,
    petergreatstpetersburgpolytechnicuniversity,
    ogarevmordoviastateuniversity,
    northernstatemedicaluniversity,
    kyrgyznationaluniversity,
    kyivpolytechnicinstitute,
    frankfurtschooloffinanceandmanagement,
    donetsknationalmedicaluniversity,
    daugavpilsuniversity,
    dnipropetrovskstatemedicalacademy,
    canterburychristchurchuniversity,
    corvinusuniversityofbudapest,
    balticinternationalacademy,
    lancasteruniversity,
    batumishotarustavelistateuniversity,
    belarusianstatemedicaluniversity,
    zaporozhyestatemedicaluniversity,
    peoplesfriendshipuniversityofrussia,
    universityofbologna,
    qiqiharmedicaluniversity,
    medicaluniversityofverna,
    tbilisimedicaluniversityhippocrates,
    wenzhoumedicaluniversity,
    glasgowcaledonianuniversity,
    gismabusinessschool,
    wroclawmedicaluniversity,
    mitworldpeaceuniversity,
    kyivschoolofeconomics,
    iuinternationaluniversityofappliedsciences,
    aghuniversityofscienceandtechnology,
    ternopilnationaltechnicaluniversity,
    keeleuniversity,
    universitycollegelondon,
    bogomoletsnationalmedicaluniversity,
    uzhhorodnationalmedicaluniversity,
    nationalaerospaceuniversity,
    universityofstrathclyde,
    velloreinstituteoftechnologyvitvellore,
    universityofexeter,
    siberianstatemedicaluniversity,
    rangpurcommunitymedicalcollege,
    primemedicalcollege,
    presidentabdulhamidmedicalcollege,
    parkviewmedicalcollege,
    avicennainternationalmedicaluniversity,
    bpkoiralainstituteofhealthsciences,
    saintpetersburgstateinstituteoftechnology,
    nationalmetallurgicalacademyofukraine,
    permstatemedicaluniversity,
    southkazakhstanmedicalacademy,
    universityofregina,
    kurskstatemedicaluniversity,
    universityforthecreativearts,
    altaistatemedicaluniversity,
    bauinternationaluniversitybatumi,
    universityofchittagong,
    jalalabadstateuniversity,
    internationalhigherschoolofmedicine,
    ivanovostatemedicalacademy,
    privolzhskyresearchmedicaluniversity,
    tulastateuniversity,
    addinwomensmedicalcollege,
    anwerkhanmodernmedicalcollege,
    dhakacentralinternationalmedicalcollege,
    dhakacommunitymedicalcollege,
    drsirajulislammedicalcollege,
    enammedicalcollegeandhospital,
    gonoshasthayasamajvittikmedicalcollege,
    berlinschoolofbusinessandinnovation,
    biratmedicalcollege,
    devdahamedicalcollegeandresearchinstitute,
    ivanofrankivsknationaluniversityofoilandgas,
    jahurulislammedicalcollege,
    khwajayunusalimedicalcollege,
    kumudiniwomensmedicalcollege,
    mainamotimedicalcollege,
    monnomedicalcollegeandhospital,
    immanuelkantbalticfederaluniversity,
    nipissinguniversity,
    northeasternuniversity,
    paceuniversity,
    purdueuniversity,
    queenslanduniversity,
    saintlouisuniversity,
    solentuniversity,
    stanforduniversity,
    swinburneuniversity,
    teessideuniversity,
    texasamuniversity,
    universityofillinois,
    universityofnewcastle,
    universityofqueensland,
    universityoftexasaustin,
    universityoftexasdallas,
    universityofwesternaustralia,
    torontometropolitanuniversity,
    torrensuniversity,
    trinitywesternuniversity,
    universityatbuffalo,
    universityofcalifornia,
    universityofcanberra,
    universityofflorida,
    universityofkent,
    universityofnewhaven,
    universityofnorthtexas,
    universityofprinceedwardisland,
    universityofsouthflorida,
    universityofsoutherncalifornia,
    universityofsouthernqueensland,
    universityoftechnology,
    universityoftexasarlington,
    universityofsunshinecoast,
    universityoftoronto,
    universityofwollongong,
    vancouverislanduniversity,
    victoriauniversitysydney,
    victoriauniversity,
    universityofcalgary,
    //christuniversitybangalore
    millenniaatlanticuniversity,
    millersvilleuniversitypennsylvania,
    milliganuniversitytennessee,
    millikinuniversityillinois,
    minnesotastateuniversitymankato,
    minnesotastateuniversitymoorhead,
    minotstateuniversity,
    mississippistateuniversity,
    mississippiuniversityforwomen,
    mississippivalleystateuniversity,
    missouribaptistuniversity,
    missouristateuniversity,
    missouriuniversityofscienceandtechnology,
    missouriwesternstateuniversity,
    monmouthuniversity,
    montanastateuniversitybillings,
    montanastateuniversitynorthern,
    montclairstateuniversity,
    millermottecollegenorthcarolina,
    millermottecollegesouthcarolina,
    millsapscollegemississippi,
    millscollegecalifornia,
    milwaukeeinstituteofartanddesign,
    milwaukeeschoolofengineering,
    mississippicollegemississippi,
    missourivalleycollege,
    mitchelltechnicalcollege,
    mohavecommunitycollege,
    mohawkcollegeontario,
    molloycollegenewyork,
    monbulkcollegevictoria,
    monmouthcollegeillinois,
    monroecollegenewyork,
    montreatcollegenorthcarolina,
    montserratcollegeofartmaine,
    montserratcollegeofartmassachusetts,
    mooretheologicalcollege,
    moravianuniversitypennsylvania,
    morehousecollegegeorgia,
    morgancommunitycollege,
    morganstateuniversity,
    morlingcollegenewsouthwales,
    morningsideuniversity,
    morrincollegequebec,
    morriscollegesouthcarolina,
    morrisoninstituteoftechnology,
    mosmamanitoba,
    mountainstatecollege,
    mountallisonuniversity,
    mountaloysiuscollege,
    mountcarmelcollegeofnursing,
    mountholyokecollege,
    mountmartyuniversity,
    mountmaryuniversity,
    mountmercyuniversity,
    mountroyaluniversity,
    mountsaintmarysuniversity,
    mountsaintvincentuniversity,
    mountstjosephuniversity,
    mountstmarysuniversity,
    mountvernonnazareneuniversity,
    mountwestcommunityandtechnicalcollege,
    msudenvercolorado,
    muhlenbergcollege,
    multnomahuniversity,
    murdochbusinessschool,
    mureskinstitutewa,
    murraystatecollege,
    murraystateuniversity,
    muskingumuniversity,
    naitalberta,
    naropauniversity,
    nashuacommunitycollege,
    nationalaboriginalislander,
    nationalcollegeofvocationaleducation,
    nationalmedicalcollege,
    nationalparalegalcollege,
    nationalparkcollege,
    nationaluniversitycalifornia,
    nationaluniversityofhealthsciences,
    naturecarecollege,
    navajotechnicaluniversity,
    navarrocollegetexas,
    nazarenetheologicalcollege,
    nbcccorporateofficefredericton,
    ncktechnicalcollege,
    neathporttalbotcollegeafan,
    neathporttalbotcollegecolegponardawe,
    nebraskachristiancollege,
    nebraskacollegeoftechnicalagriculture,
    nebraskaindiancommunitycollege,
    nebraskamethodistcollege,
    nebraskawesleyanuniversity,
    neoshocountycommunitycollege,
    nepalmedicalcollege,
    nepalgunjmedicalcollege,
    neumontcollegeofcomputerscience,
    nevadastatecollege,
    newbrunswickbibleinstitute,
    newbrunswickcollegeofcraftanddesign,
    newcollegeofflorida,
    newenglandcollege,
    newjerseycityuniversity,
    newjerseyinstituteoftechnology,
    newmexicohighlandsuniversity,
    newmexicoinstituteofminingandtechnology,
    newmexicojuniorcollege,
    newmexicomilitaryinstitute,
    newmexicostateuniversityalamogordo,
    newmexicostateuniversitycarlsbad,
    newmexicostateuniversitygrants,
    newmexicostateuniversity,
    newmexicoveteransupwardbound,
    newrivercommunityandtechnicalcollege,
    newschoolofarchitectureanddesign,
    newsouthwalespoliceacademy,
    newyorkcollegeofhealthprofessions,
    newyorkfilmacademy,
    newyorkschoolofinteriordesign,
    newyorkuniversity,
    newberrycollege,
    newcastleuniversity,
    newmancollegeireland,
    newmantheologicalcollege,
    newmanuniversitykansas,
    nhticoncordscommunitycollege,
    niaccnorthiowaareacommunitycollege,
    niagaracollegeontario,
    nichollsstateuniversity,
    nicolavalleyinstituteoftechnology,
    nightingalecollege,
    nipawinbiblecollege,
    nipissinguniversityontario,
    nobelmedicalcollege,
    nocholscollegemassachusetts,
    norquestcollegeedmontoncampus,
    northamericanuniversity,
    northarkansascollege,
    northcarolinaagriculturalandtechnicalstateuniversity,
    northcarolinacentraluniversity,
    northcarolinastateuniversity,
    northcarolinawesleyancollege,
    northcentralcollegeillinois,
    northcentraluniversity,
    northdakotastateuniversity,
    northeastmedicalcollege,
    northgreenvilleuniversitynorthcarolina,
    northgreenvilleuniversitysouthcarolina,
    northidahocollege,
    northislandcollege,
    northparkuniversity,
    northscotlandcollege,
    northwestcollegesaskatchewan,
    northwestregionalcollegenorthernireland,
    northwestregionalcollegederrylondonderry,
    northwestregionalcollegelimavady,
    northcentraluniversityarizona,
    northeastalabamacommunitycollege,
    northeasttexascommunitycollege,
    northeastwisconsintechnicalcollege,
    northeasternillinoisuniversity,
    northeasternuniversitymassachusetts,
    northernarizonauniversity,
    northernillinoisuniversity,
    northernkentuckyuniversity,
    northernlakescollege,
    northernlightscollege,
    northernmichiganuniversity,
    northernnewmexicocollege,
    northernregionalcollegeballymoney,
    northernregionalcollegeantrim,
    northernregionalcollegelarne,
    northernregionalcollegenorthernireland,
    northernstateuniversity,
    northernvermontuniversity,
    northlandpioneercollege,
    northlandscollegesaskatchewan,
    northpointbiblecollege,
    northumbriauniversity,
    northwestarkansascommunitycollege,
    northwestcareercollege,
    northwestcollegeofartanddesign,
    northwestcollegewyoming,
    northwestiowacommunitycollege,
    northwestmissouristateuniversity,
    northwestnazareneuniversity,
    northwestuniversity,
    northwestvistacollege,
    northwesterncollegeiowa,
    northwesternconnecticutcommunitycollege,
    northwesternoklahomastateuniversity,
    northwesternstateuniversity,
    northwesternuniversityillinois,
    northwestshoalscommunitycollege,
    northwoodtechnicalcollege,
    northwooduniversity,
    norwalkcommunitycollege,
    norwichuniversity,
    nossicollegeofart,
    notredamecollege,
    notredameofmarylanduniversity,
    nottinghamtrentuniversity,
    novascotiaagriculturalcollege,
    novascotiateacherscollege,
    novasouthwesternuniversity,
    nptcgroupofcollege,
    nrcballymena,
    nscaduniversity,
    nscccentreofgeographicsciences,
    nsccinstituteoftechnologycampus,
    nscecenovascotia,
    nuetahidatsasahnishnhscommunitycollege,
    nunavutarcticcollege,
    nunezcommunitycollege,
    nungalinyacollege,
    nyackcollege,
    oaklandcityuniversity,
    oaklanduniversity,
    oberlincollege,
    ocaduniversity,
    occidentalcollege,
    oceancountycollege,
    odessacollege,
    oglethorpeuniversity,
    ohiobusinesscollege,
    ohiochristianuniversity,
    ohiodominicanuniversity,
    ohionorthernuniversity,
    ohiostateuniversity,
    ohiotechnicalcollege,
    ohiouniversity,
    ohiovalleycollegeoftechnology,
    ohiovalleyuniversity,
    ohiovalleyuniversitywestvirginia,
    ohiowesleyanuniversity,
    okanagancollegekelownacampus,
    oklahomacityuniversity,
    oklahomastateuniversity,
    oklahomawesleyanuniversity,
    olddominionuniversity,
    oldsuncommunitycollege,
    oldscollegealberta,
    olincollegeofengineering,
    olivetcollegemichigan,
    olivetnazareneuniversity,
    ontariotechuniversity,
    oralrobertsuniversity,
    orangecoastcollege,
    oregoninstituteoftechnology,
    oregonstateuniversity,
    otiscollegeofartanddesign,
    ottawauniversity,
    otterbeinuniversity,
    ouachitabaptistuniversity,
    oultoncollegemoncton,
    ourladyofthelakeuniversity,
    ozarkacollegearkansas,
    paceuniversitynewyork,
    pacificlutheranuniversity,
    pacificnorthwestcollegeofart,
    pacificrimchristianuniversity,
    pacificstatesuniversity,
    pacificunioncollege,
    palmbeachatlanticuniversity,
    palmercollegeofchiropracticmaincampus,
    paloaltocollegetexas,
    panolacollegetexas,
    paradisevalleycommunitycollege,
    parisjuniorcollegetexas,
    parkeruniversitycampus,
    parklandcollegemaincampus,
    parklandcollegetradesandtechnologycentre,
    parklandcollegekelvington,
    paulquinncollegetexas,
    pavillonjraymondfrenette,
    peaceriverbibleinstitute,
    pearsoncollegeuwc,
    pembrokescollegewales,
    pennstateuniversity,
    pennsylvaniacollegeofartanddesign,
    pennsylvaniacollegeofhealthsciences,
    pennsylvaniacollegeoftechnology,
    pennsylvaniahighlandscommunitycollege,
    pepperdineuniversitycalifornia,
    perrytechnicalinstitutewashington,
    perthbiblecollegewesternaustralia,
    perustatecollegenebraska,
    pfeifferuniversity,
    philandersmithcollegearkansas,
    phillipscommunitycollegeoftheuniversity,
    phoenixcollegearizona,
    piedmonttechnicalcollege,
    pierpontcommunityandtechnicalcollege,
    pimamedicalinstitutelasvegas,
    pimamedicalinstitutearizona,
    pittsburgstateuniversity,
    pitzercollegecalifornia,
    plazacollegenewyork,
    plymouthstateuniversity,
    pointlomanazareneuniversitycalifornia,
    pointuniversitygeorgia,
    polytechnicuniversityorlandocampus,
    purdueuniversityfortwayne,
    pomonacollegecalifornia,
    pontificalcollegejosephinum,
    portagecollegelaclabichecampus,
    portervillecollegecalifornia,
    portlandstateuniversity,
    postuniversityconnecticut,
    prairiecollegealberta,
    prairieviewaandmuniversity,
    prattcommunitycollegekansas,
    prattinstitutenewyork,
    presbyteriancollege,
    prescottcollegearizona,
    princetonuniversity,
    presentationcollegesouthdakota,
    providencecollegerhodeisland,
    providenceuniversity,
    provocollegeutah,
    pueblocommunitycollegecolorado,
    purdueuniversityindiana,
    qimrberghofermedicalresearchinstitute,
    queenmaryuniversityoflondon,
    queensuniversitybelfast,
    queensuniversityofcharlotte,
    questuniversitycanada,
    quincycollegemassachusetts,
    quincyuniversityillinois,
    quinnipiacuniversity,
    qutgardenspointcampus,
    racmavictoria,
    ramapocollegeofnewjersey,
    randalluniversity,
    rangercollegetexas,
    rankentechnicalcollegemissouri,
    rasmussenuniversityfargo,
    rasmussenuniversitywisconsin,
    redcrowcommunitycollege,
    reddeerpolytechnicuniversity,
    redrivercollegegimli,
    redrivercollegeadultlearningcentre,
    redrivercollegepeguis,
    redrivercollegeprincessstreet,
    redrivercollegesteinbachcommunity,
    redrivercollegesaatcsouthport,
    redrivercollegesaatcwinnipeg,
    reedcollegeoregon,
    regentcollegevancouver,
    regentuniversityvirginia,
    regiscollegemassachusetts,
    regisuniversity,
    remingtoncollegegreenspointcampus,
    remingtoncollegelouisiana,
    remingtoncollegetennessee,
    rhodeislandcollege,
    rhodeislandschoolofdesign,
    rhodescollegetennessee,
    riceuniversity,
    rideruniversity,
    ridleycollegevictoria,
    ringlingcollegeofartanddesign,
    riosaladocollegearizona,
    riponcollegewisconsin,
    rivervalleycommunitycollege,
    rivieruniversity,
    robertmorrisuniversity,
    robertsoncollegemanitoba,
    rockforduniversity,
    rockhurstuniversity,
    rockymountaincollegeofartdesign,
    rockymountaincollegemontana,
    rogerwilliamsuniversity,
    rogersstateuniversity,
    rolinscollegeflorida,
    rooseveltuniversity,
    rosehulmaninstituteoftechnology,
    rosemountcollegepennsylvania,
    rowanuniversity,
    roxburycommunitycollege,
    royalaustralianandnewzealandcollege,
    royalhollowayengland,
    royalmilitarycollegeofcanada,
    royalwelshcollege,
    rrcpolytechlanguagetrainingcentre,
    rrcpolytechportagecampus,
    rrcpolytechsteinbachcampus,
    rrcpolytechwinnipeg,
    rustcollegemississippi,
    rutgersuniversitynewarkcampus,
    rutgersuniversitycamden,
    rutgersnewbrunswick,
    sacredheartuniversity,
    saginawvalleystateuniversity,
    saintanselmcollege,
    saintaugustinesuniversity,
    saintcloudstateuniversity,
    saintelizabethuniversity,
    saintfrancisuniversity,
    sainthermantheologicalseminary,
    saintjohnsuniversity,
    saintjosephabbeyandseminarycollege,
    saintjosephscollegeofmaine,
    saintjosephsuniversity,
    saintleouniversity,
    saintlouisuniversitymissouri,
    saintmartinsuniversity,
    saintmaryscollegeofcalifornia,
    saintmarysuniversityofminnesota,
    saintmarysuniversitynovascotia,
    saintpauluniversity,
    saintpetersuniversity,
    saintvincentcollege,
    saintvladimirscollege,
    saintxavieruniversity,
    salemcollegenorthcarolina,
    salemstateuniversitymaine,
    salemstateuniversitymassachusetts,
    salemuniversitywestvirginia,
    salinaareatechnicalcollege,
    salisburyuniversity,
    salvereginauniversity,
    samhoustonstateuniversity,
    samforduniversity,
    samuelmerrittuniversity,
    sanantoniocollege,
    sandiegostateuniversity,
    sanfranciscostateuniversity,
    sanignaciouniversity,
    sanjosestateuniversity,
    oakwooduniversityalabama,
    sanjuancollegenewmexico,
    sansistocollegequeensland,
    santaclarauniversity,
    santafecollegeflorida,
    santafecommunitycollege,
    santiagocanyoncollege,
    sarahlawrencecollege,
    saskatchewanindianinstituteoftechnologies,
    saskatchewaninstituteofappliedscienceandtechnology,
    saskatchewanpolytechnic,
    saultcollegeontario,
    schillerinternationaluniversity,
    schoolofvisualarts,
    schreineruniversity,
    scottsdalecommunitycollege,
    scrippscollegecalifornia,
    sealcovecampus,
    seattlepacificuniversity,
    seattleuniversity,
    seminolestatecollege,
    setonhalluniversitynewjersey,
    setonhilluniversitypennsylvania,
    sewardcountycommunitycollege,
    shafstoninternationalcollege,
    shaheedmonsuralimedicalcollege,
    shawuniversity,
    shawneestateuniversity,
    sheltonstatecommunitycollege,
    shepherduniversity,
    sheridancollegewyoming,
    shoalhavencommunitycollege,
    shoalhavenmarineandfreshwatercentre,
    shoalhavenrivercollege,
    shortercollegearkansas,
    sierranevadauniversity,
    simmonsuniversity,
    simpsoncollegeiowa,
    sintegleskauniversity,
    sittingbullcollege,
    smithcollegemassachusetts,
    sneadstatecommunitycollege,
    soasuniversityoflondon,
    sofiauniversity,
    sokauniversityofamerica,
    southarkansascommunitycollege,
    southcarolinastateuniversity,
    southcoastcolleges,
    southcollegetennessee,
    southdakotamines,
    southdakotastateuniversity,
    
}
