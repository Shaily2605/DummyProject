// export const universityofwolverhampton= {
//     "Title": "",
//     "shortTitle": " ",
//     "location": " ",
//     "type": "bb",
//     "rating": "vv",
//     "shareLink": "www.google.com",
//     data: [


//         {
//             type: 'text',
//             title: '',
//             img: '',
//             data: '<p></p><br><p></p><br><p></p><br><p></p><br><p></p>'
//         },

//         {
//             "type": "table",
//             "title": "",
//             "info": "<b></b>",
//             "col": [
//             ],
//             "row": [
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],
//                 ["<b></b>", ""],


//             ]
//         },
//      {
//             "type": "list-bollet",
//             "title": "",
//             "info": "<b></b>",
//             "img": '',
//             "data": [
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",
//                 "",


//             ]
//         },

//         {
//             "type": "table",
//             "title": "",
//             "info": "<b></b>",
//             "col": [
//                 "World	",
//                 "Country",
//             ],

//             "row": [
//                 {
//                     "World": "",
//                     "Country": "",
//                 },

//             ]
//         },

//         {
//                 "type": "list-bollet",
//                 "title": "",
//                 "info": "<b></b>",
//                 "img": '',
//                 "data": [
//                     "",


//                 ]
//             },
//             {
//                 "type": "table",
//                 "title": "",
//                 "info": "<b></b>",
//                 "col": [
//                     "Particular		",
//                     "Amount in USD", 
//                     "Amount in RS", 
//                 ],

//                 "row": [
//                     {
//                         "Particular": "<b></b>",
//                         "Amount in USD":"",
//                         "Amount in RS":"",
//                     },

//                 ]
//             },
//             {
//                 type: 'text',
//                 title: '',
//                 img: '',
//                 data: '<p><b> Note:</b> </p> '
//             },



//         {
//             type:'meta',
//             data:[
//               {name: "description" , content:"", itemprop:"", property: "",scheme:'' },
//               {name: "og:type" , content:"website", itemprop:"", property: "", },
//               {name: "og:image" , content:"", itemprop:"", property: "",scheme:'' },
//               {name: "og:description" , content:"", itemprop:"", property: "",scheme:'' },
//               {name: "og:url" , content:"", itemprop:"", property: "",scheme:'' },


//               {name: "charset" , content:"utf-8", itemprop:"", property: "",scheme:'' },
//               {name: "google" , content:"notranslate", itemprop:"", property: "",scheme:'' },
//               {name: "viewport" , content:"width=device-width, initial-scale=1, shrink-to-fit=no, maximum-scale=1, user-scalable=no", itemprop:"", property: "",scheme:'' },




//             ]
//           },
//           {
//             type:'link',
//             data:[
//               { rel:'alternate', href:'https://www.selectyouruniversity.com/uk/university-of-wolverhampton hreflang=en-Us '},
//               { rel:'canonical', href:''},
//               { rel:'icon', href:'../images/fevicon.png type="image/png"'},
//             ],
//             url:""
//           },
//           {
//             type:"page-Title",
//             data:"",
//           }

//     ]}


export const kharkivnationaluniversityofarts = {
    "Title": "Kharkiv National University of Arts, Ukraine",
    "shortTitle": "Kharkiv National University of Arts, Ukraine",
    "location": " Ukraine",
    "type": "bb",
    "rating": "vv",
    "shareLink": "www.google.com",
    "url": "kharkiv-national-university-of-arts",
    "info": [
        {
            type: 'title',
            title: 'Kharkiv National University of Arts, Ukraine'
        },

        {
            type: 'text',
            title: 'About Kharkiv National University of Arts, Ukraine',
            // img: 'https://www.selectyouruniversity.com/images/kharkiv-national-university-of-arts.jpg',
            data: '<p>The Kharkiv National University of Arts is the top-leading institution of music and drama in Ukraine, It trains nearly 900 undergraduates, graduates and postgraduates.</p><p>It was established in 1917 located in Kharkiv, Ukraine and named after I. P. Kotlyarevsky,</p><p>The Kharkiv National University of Arts has an individual approach to education and professional training and to develop and encourage the formation of a uniquely creative personality.</p><p>More than 10,000 musicians and theatre workers have graduated from the university.</p><p>The graduated students are successfully working in different countries across the globe including the United States, United Kingdom, France, Germany, Denmark, Australia, Israel, Russia, and others.</p>'
        },

        {
            "type": "table-title",
            "title": "Kharkiv National University of Arts - Quick Highlights",
            "info": "Here is some quick information that every student must know to take admission at Kharkiv National University of Arts:</b>",
            "col": [
            ],
            "row": [
                ["<b>Tuition Fees (approx)</b>", "3800 USD"],
                ["<b>Program</b>", "Arts and Culture"],
                ["<b>Course Duration</b>", "4 years"],
                ["<b>Medium of Teaching</b>", "English Language"],
                ["<b>University Ranking</b>", "World Rank - 9455<br>Country Rank - 161"],
                ["<b>Recognition</b>", "Ministry of Education of Ukraine"],


            ]
        },
        {
            "type": "list-bollet",
            "title": "Why Choose Kharkiv National University of Arts for Higher Studies?",
            "info": "Everything at one place for the convenience of the students, check out the benefits to study at Kharkiv National University of Arts:</b>",
            "img": '',
            "data": [
                "The Kharkiv National University of Arts provides a high standard of education and improves their professional knowledge and skills to the students coming from different countries. ",
                "The organizational structure of the institute is devised to offer maximum support to the students for excellence in academic activities.",
                "The Kharkiv National University of Arts provides the modern and adequate academic infrastructure to ensure that the students can get the best education exposure.",
                "The university offers arts education at affordable prices that allow the students to get an excellent education at reduced rates.",
                "It has official recognition from the Ministry of Education of Ukraine, thus the arts degree students got from this college is accepted globally.",
                "The institute has international cooperation with other various nations.",
                "The students have a globally recognized degree that guarantees 100 % job placement at any place in the world.",
                "The students need not appear for any university entrance test for getting admission in the arts stream at Kharkiv National University of Arts.",
                "The medium of teaching is the English language which makes it easier for Indian students.",
                "IELTS or TOEFL is not required.",
                "The professors are quite friendly and the way of teaching is fantastic to clear all doubts of the students.",
                "The Kharkiv National University of Arts invites lecturers to make jury members in international competitions and festivals in different cities across the globe and also conducts master classes in other countries.",
                "The university also conducts considerable research with foreign music and theatre higher educational institutions.",


            ]
        },

        {
            "type": "table",
            "title": "Kharkiv National University of Arts - Ranking 2021",
            "info": "According to Uni rank, check out the country & world ranking of the Kharkiv National University of Arts:</b>",
            "col": [
                "World",
                "Country",
            ],

            "row": [
                {
                    "World": "9455",
                    "Country": "161",
                },

            ]
        },


        {
            type: 'text',
            title: 'Medium of Teaching',
            info: 'The university offers quality education in English medium to provide Arts education:</b>',
            data: '<p>The medium of instruction for all foreign students at the Kharkiv National University of Arts in the English language.</p> '
        },

        {
            type: 'text',
            title: 'Accreditation and Recognition',
            info: 'The Arts degree from the Kharkiv National University of Arts is accredited and recognized by several Arts bodies:</b>',
            data: '<p>The Kharkiv National University of Arts is accredited with the status of IV level and has a license from the Ministry of Education and Science of Ukraine</p> '
        },



        {
            "type": "table",
            "title": "Living Cost of Kharkiv",
            "info": "Kharkiv has a very low cost of monthly expenses given below in the table:</b>",
            "col": [
                "Particular",
                "Amount in USD",
                "Amount in RS",
            ],

            "row": [
                {
                    "Particular": "<b>Hostel</b>",
                    "Amount in USD": "83 USD",
                    "Amount in RS": "5810 Rs",
                },
                {
                    "Particular": "<b>Food</b>",
                    "Amount in USD": "133 USD",
                    "Amount in RS": "9312 Rs",
                },
                {
                    "Particular": "<b>Transport</b>",
                    "Amount in USD": "8 USD",
                    "Amount in RS": "609 Rs",
                },

            ],
            "heading": "<p><b Note:</b>1$ = 70 Rs. </p>"
        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine" },
                { name: "description", content: "The Kharkiv National University of Arts is the top-leading institution of music and drama in Ukraine It was established in 1917 located in Kharkiv, Ukraine" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts" }
            ]
        }

    ],
    "coursesandfees": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - courses & Fees"

        },
        {
            "type": "table",
            "title": "Kharkiv National University of Arts - Fee Structure",
            "info": "The Kharkiv National University of Arts offers a low fee structure to worldwide students to study Arts:</b>",
            "col": [
                "Particular",
                "Fee in USD",
                "Fee in Rs",
            ],

            "row": [
                {
                    "Particular": "<b>English medium</b>",
                    "Fee in USD": "3800 USD",
                    "Fee in Rs": "2,66,000 Rs"
                },
                {
                    "Particular": "<b>Russian medium</b>",
                    "Fee in USD": "3000 USD",
                    "Fee in Rs": "2,10,000 Rs"
                },
                {
                    "Particular": "<b>Hostel fee</b>",
                    "Fee in USD": "1000 USD",
                    "Fee in Rs": "70,000 Rs"
                },


            ],
            "heading": "<p><b Note:</b>1$ = 70 Rs. </p>"

        },
        {
            "type": "table-title",
            "title": "Departments at Kharkiv National University of Arts",
            "info": "The Kharkiv National University of Arts has a wide range of departments offered to the global students coming here to pursue arts stream:</b>",
            "textBelowInfo": "1 The Faculty of Performing and Musicology",
            "col": [

            ],

            "row": [
                ["Department of Special Piano", "Department of Concertmaster Skills"],
                ["Department of Chamber Ensemble", "Department of Choral Conducting"],
                ["Department of Solo Singing and Opera Training", "Department of Composition and Instrumentation"],
                ["Department of Music Theory", "Department of Interpretology and Music Analysis"],
                ["Department of History of Ukrainian and Foreign Music", "-"],
            ]
        },
        {
            "type": "table-title",
            "title": "",
            "info": "2 Orchestra Faculty",
            "col": [

            ],

            "row": [
                ["Department of Orchestral String Instruments", "Department of Orchestral Wind Instruments and Opera and Symphony Conducting"],
                ["Department of Pop and Jazz Music", "Department of Folk Instruments of Ukraine"],
                ["Department of General and Specialized Piano", "Department of Theory and Methods of Art Education"],
                ["Department of Foreign Languages", "Department of Social Sciences"],
                ["Department of Physical Education", "-"],
            ]
        },
        {
            "type": "table-title",
            "title": "",
            "info": "3 Theatre faculty",
            "col": [

            ],

            "row": [
                ["Department of Theater Studies", "Department of Drama Theater Directing"],
                ["Department of Actor's Skills", "Department of Actor's Skills and Animation Theater Directing"],
                ["Department of Stage Language", "-"],
            ]
        },


        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - courses & Fees" },
                { name: "description", content: "Kharkiv National University of Arts is the top-leading institution of music and drama ; Tuition Fee with Hostel. Check available courses and fees" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - courses & Fees"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/courses-and-fees" }
            ]
        }
    ],
    "admission": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - Admission 2023"

        },
        {
            "type": "list-bollet",
            "title": "Eligibility Criteria",
            "info": "According to Uni rank, check out the country & world ranking of the Kharkiv National University of Arts:</b>",
            "data": [
                "The candidates applying for the Arts course must have at least 17 years of age or shall complete 17 years before 31st December of the admission year.",
                "The students should pass the higher secondary exam with an aggregate of 50% marks.",
                "The selected students belonging to foreign countries must have a valid passport.",
            ]
        },
        {
            "type": "step-list",
            "title": "Admission Process",
            "info": "To apply at Kharkiv State Kotlyarevsky University of Arts, the candidates must follow these admission steps:</b>",
            "data": [
                "<b>Step 1:</b> The students must fill the online application form soon with all the important details.",
                "<b>Step 2:</b> The global students should upload the scan copies of academic documents.",
                "<b>Step 3:</b> The candidates submit the application form with passport size photographs.",
                "<b>Step 4:</b> The students should pay the examination fee.",
                "<b>Step 5:</b> The candidates must proceed to the following for evaluation and interview.",
                "<b>Step 6:</b> The selected students can go ahead with a valid passport.",
            ]
        },
        {
            "type": "list-bollet",
            "title": "Documents Required",
            "info": "The candidates enrolling in college must kindly make sure of submitting all documents at the time of physical reporting:</b>",
            "data": [
                "Higher secondary education certificates",
                "Birth certificate",
                "Application form",
                "Migration certificate",
                "Passport size photographs",
                "Bank receipt",
                "Valid passport",
                "Invitation letter",
                "Passing certificate",
                "Caste certificate",
                "HIV test certificate",
                "Covid-19 report",
                "Medical reports",

            ]
        },
        {
            "type": "table",
            "title": "Important Dates - Intake 2021",
            "info": "The students must check out some important admission dates of Kharkiv National University of Arts:</b>",
            "col": [
                "Events",
                "Dates",

            ],
            "row": [
                {
                    "Events": "<b>Application Start Date</b>",
                    "Dates": "Yet to be declared"
                },
                {
                    "Events": "<b>Invitation Letter</b>",
                    "Dates": "Within 2 weeks"
                },
                {
                    "Events": "<b>Admission Start Date</b>",
                    "Dates": "Yet to be declared"
                },
                {
                    "Events": "<b>Last Date of Admission</b>",
                    "Dates": "-"
                },
            ]
        },
        {
            "type": "list-bollet",
            "title": "Facilities Provided at Kharkiv National University of Arts",
            "info": "Top-class facilities are furnished at Kharkiv National University of Arts:</b>",
            "data": [
                "Kharkiv National University of Arts are well equipped and modern classrooms with good seating arrangements.",
                "The Kharkiv National University of Arts has a spacious, well-furnished library with a comfortable sitting arrangement and collection of textbooks.",
                "The Kharkiv National University of Arts has a Food facility at a reasonable cost for the students coming from all corners of the world.",
                "The College has an air-conditioned auditorium to conduct guest lectures, conferences, presentations, and seminars.",
                "The Kharkiv National University of Arts has residence for the comfortable living of the students.",

            ]
        },
        {
            "type": "list-bollet",
            "title": "",
            "info": "",
            "data": [
                "Classrooms",
                "Library",
                "Canteen",
                "Auditorium",
                "Hostel",
            ]
        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - Admission 2023" },
                { name: "description", content: "Admission step by step. Choose the appropriate section in the system of Internet Recruitment of Candidates.Click Here TO REGISTER" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - Admission 2023"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/admission" }
            ]
        }
    ],
    "review": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - Reviews"

        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - Reviews" },
                { name: "description", content: "Find out what makes this college so special by reading student reviews. Click here to see reviews" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - Reviews"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/reviews" }
            ]
        }
    ],
    "placement": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - Placement"

        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - Placement" },
                { name: "description", content: "Placement in the college is best because it has a record of 100% placement, Check top recruiters " },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - Placement"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/placement" }
            ]
        }
    ],
    "gallery": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - Gallery"

        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - Gallery" },
                { name: "description", content: "See what life is like as a student at one of the best institutes. Check gallery here" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - Gallery"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/gallery" }
            ]
        }
    ],
    "scholarship": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - Scholarship"

        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - Scholarship" },
                { name: "description", content: "college has a partnership with Siemens they provide scholarships who come from lower economical backgrounds. Check scholarship and bursary" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - Scholarship"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/scholarship" }
            ]
        }
    ],
    "faculty": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - Faculty"

        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - Faculty" },
                { name: "description", content: "Browse list of faculties offered from this University to choose from. Click here for departments" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - Faculty"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/faculty" }
            ]
        }
    ],
    "news": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - News & Articles"

        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - News & Articles" },
                { name: "description", content: "Read latest News, Articles about Cutoffs, Placements, courses, Fees. Check all the news and articles here" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - News & Articles"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/news-and-articles" }
            ]
        }
    ],
    "hostel": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - Hostel"

        },
        {
            "type": "list-bollet",
            "title": "Hostel & Accommodation",
            "info": "The University provides world-class hostel facilities in the university campus to worldwide students:</b>",
            "data": [
                "Accommodation charges for every year are 1000 USD",
                "The hostel has twin sharing and newly renovated rooms with furniture and utensils for better stay away from.",
                "The hostel is enabled with internet connection for study purposes.",
                "The hostels are allocated on a sharing basis.",
                "The hostel offers separate space for boys and girls both.",
                "The students are provided with a common kitchen offering the option of self-cooking.",
                "The hostel is under CCTV surveillance and supervision of wardens.",
                "The hostel mess provides 3 times fresh and healthy food in the hostel premises.",
                "The hostel has nearby areas of Indian restaurants, cafes, and medical centres.",
                "The hostel rooms are very well-equipped along with all modern facilities -",

            ]
        },
        {
            "type": "list-bollet",
            "title": "",
            "info": "",
            "data": [
                "Bedsheet",
                "pillow",
                "Fan",
                "Bed",
                "Blanket",
                "Reading Hall",
                "Table",
                "Gym",
            ]
        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - Hostel" },
                { name: "description", content: "This college provides an excellent Hostel and Accommodation facilities, students can take advantage of it. Check detailed accomodation" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - Hostel"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/hostel" }
            ]
        }
    ],
    "faq": [
        {
            type: 'title',
            title: "Kharkiv National University of Arts, Ukraine - FAQ"

        },
        {
            type: 'question-list',
            title: 'Kharkiv National University of Arts - Important FAQs',
            info: 'Apart from the information provided, here are some frequently asked questions on Quora and Careers 360:</b>',
            data: [
                {
                    "ques": "Q. Can we pursue Arts in the Kharkiv National University of Arts without appearing for IELTS & TOEFL examination?",
                    "ans": "The IELTS & TOEFL examination is not mandatory to pursue Arts in Kharkiv National University of Arts."
                },
                {
                    "ques": "Q. What is the food cost of the Kharkiv National University of Arts for an Arts course?",
                    "ans": "133 USD is required to study at the Kharkiv National University of Arts."
                },
                {
                    "ques": "Q. Is the vegetarian food available at the Kharkiv National University of Arts?",
                    "ans": "The Vegetarian food is available in the campus canteen of Kharkiv National University of Arts."
                },
                {
                    "ques": "Q. Is it worth studying Arts at the Kharkiv National University of Arts?",
                    "ans": "The Kharkiv National University of Arts is the best choice as the university provides quality education with low fees."
                },
                {
                    "ques": "Q. What is the duration of the Arts course at the Kharkiv National University of Arts?",
                    "ans": "The students must complete 4 years of Arts course at the Kharkiv National University of Arts."
                },
                {
                    "ques": "Q. Is it possible to pay the tuition fee for an art course in installments at the Kharkiv National University of Arts?",
                    "ans": "The students can pay a fee in installments to study Arts courses at Kharkiv National University of Arts"
                },
            ]
        },
        {
            type: "meta",
            meta: [
                { name: "title", content: "Kharkiv National University of Arts, Ukraine - FAQ" },
                { name: "description", content: "the college is present among top university present in the country. Click here to see FAQs" },
            ],
        },
        {
            type: "meta-title",
            title: "Kharkiv National University of Arts, Ukraine - FAQ"
        },
        {
            type: "meta-links",
            link: [
                { rel: "canonical", href: "https://www.selectyouruniversity.com/university/kharkiv-national-university-of-arts/faq" }
            ]
        }
    ]



}